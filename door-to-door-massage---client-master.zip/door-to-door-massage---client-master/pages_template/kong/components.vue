<!-- 微信登录 -->
<template>
	<view class="mp-weixin">
		
	</view>
</template>

<script>
export default {
	name: "mp-weixin",
	//emits: ["click"],
	props: {
		name: {
			Type: String,
			default: ""
		}
	},
	data: function() {
		// 组件创建时,进行数据初始化
		return {
			
		};
	},
	mounted() {
		this.init();
	},
	methods: {
		// 初始化
		init() {
			
		},
		// 触发自定义事件
		onClick(e) {
			this.$emit("click", e);
		}
	},
	// 计算属性
	computed: {
		
	}
};
</script>

<style lang="scss" scoped>
.mp-weixin{

}
</style>

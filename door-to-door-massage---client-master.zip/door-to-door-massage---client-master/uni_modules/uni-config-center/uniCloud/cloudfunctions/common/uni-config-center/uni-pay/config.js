const fs = require('fs');
const path = require('path')
module.exports = {
	// 统一 - 支付回调地址,格式为 "服务空间ID":"URL化地址"
	"notifyUrl": {
		// 本地开发环境
		"mp-70527b73-a69f-4c9b-b661-57c830844dbe": "https://fc-mp-70527b73-a69f-4c9b-b661-57c830844dbe.next.bspapp.com/http/vk-pay",
		// 线上正式环境
		"mp-70527b73-a69f-4c9b-b661-57c830844dbe": "https://fc-mp-70527b73-a69f-4c9b-b661-57c830844dbe.next.bspapp.com/http/vk-pay"
	},
	// 此密钥主要用于跨云函数回调或回调java、php等外部系统时的通信密码（建议修改成自己的，最好64位以上，更加安全）
	// 详细介绍：https://vkdoc.fsq.pub/vk-uni-pay/uniCloud/pay-notify.html#%E7%89%B9%E5%88%AB%E6%B3%A8%E6%84%8F
	"notifyKey": "B4498B860EAB3CA3ADF9D07F891D7D78B4498B860EAB3CA3ADF9D07F891D7D78",
	// 是否将支付宝APP支付转H5支付 开启后无需再申请APP支付(共用当面付API)
	// "alipayAppPayToH5Pay":true,
	// 支付宝系统服务商ID，可不填
	"sysServiceProviderId": "2088731216435275",
	// 微信
	"wxpay": {
		// 微信 - 小程序支付
		"mp-weixin": {
			"appId": "",
			"secret": "",
			"mchId": "",
			"key": "",
			"pfx": fs.readFileSync(__dirname + '/wxpay/wxpay.p12')
		},
		// 微信 - APP支付
		"app-plus": {
			"appId": "",
			"secret": "",
			"mchId": "",
			"key": "gdfghjksdfghjujhijhgfstyhbgdloin",
			"pfx": fs.readFileSync(__dirname + '/wxpay/wxpay.p12')
		},
		// 微信 - H5网站二维码支付
		"h5": {
			"appId": "",
			"secret": "",
			"mchId": "",
			"key": "gdfghjksdfghjujhijhgfstyhbgdloin",
			"pfx": fs.readFileSync(__dirname + '/wxpay/wxpay.p12')
		},
		// 微信 - 公众号支付
		"h5-weixin": {
			"appId": "",
			"secret": "",
			"mchId": "",
			"key": "gdfghjksdfghjujhijhgfstyhbgdloin",
			"pfx": fs.readFileSync(__dirname + '/wxpay/wxpay.p12')
		},
		// 微信 - 手机外部浏览器H5支付
		"mweb": {
			"appId": "",
			"secret": "",
			"mchId": "",
			"key": "gdfghjksdfghjujhijhgfstyhbgdloin",
			"pfx": fs.readFileSync(__dirname + '/wxpay/wxpay.p12'),
			// 场景信息，必填
			"sceneInfo": {
				"h5_info": {
					"type": "Wap", // 此值固定Wap
					"wap_url": "", // 你的H5首页地址，必须和你发起支付的页面的域名一致。
					"wap_name": "真到位", // 你的H5网站名称
				}
			}
		},
		// 微信 - 转账到零钱 v3版本
		"transfer": {
			"appId": "",
			"mchId": "",
			"apiV3key": "", // api v3密钥
			"appCertSn": "", // 商家应用证书的序列号
			"privateKey": "", // 商家私钥
			"wxpayPublicCertSn": "", // 微信支付公钥证书的序列号
			"wxpayPublicCertContent": "", // 微信支付公钥内容
		}
	},
	// 支付宝（证书记得选java版本）
	"alipay": {
		// 支付宝 - 小程序支付配置
		"mp-alipay": {
			"mchId": "",
			"appId": "",
			"privateKey": "",
			"alipayPublicCertPath": path.join(__dirname, 'alipay/alipayCertPublicKey_RSA2.crt'),
			"alipayRootCertPath": path.join(__dirname, 'alipay/alipayRootCert.crt'),
			"appCertPath": path.join(__dirname, 'alipay/appCertPublicKey.crt'),
			"sandbox": false
		},
		// 支付宝 - APP支付配置
		"app-plus": {
			"mchId": "2088541851942821",
			"appId": "2021003186686074",
			"privateKey": "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDFgXFfIj7hB6WkRZ0ujWqf2z/v6apSBsgQIfJIO2YCZsR9tgBX0wOfxJviQZZUZ89o75OEqFTK1GYKAcihvd8Qm8YbDBiUXOoK4SJp7pTN6HP5rvKFkK/mHKzdQCs72psZl7X2RnVjCr7TFIcyoEMJDHf1+eredgVAPxuip8Uftipyqf3dmUHXO27TwBVCfzkoew7sCHrTHN1sFZstHx4OG1vcm3dhzoDPgmDkGapA9ATqi1hH/KCXcoGmsSJ+bk5ikZVdd198rx5zixrAoW1OnbISVOvcgnJ9SrUv+fe4cKjJgUE3wwjPreEerxA0juMPGD9rwXMH5jm63JyItjl/AgMBAAECggEBAK2VUY3aLEdckDErWbTzZzWt3ai+xgmnmifLngPr6IDNz33o+q41cCb4BkU5faUbQ8gnX5Ck3TkSqce7v5ifprATKG7XF7c1XiFHsxZFMJUz6tIT92R6QI5Ov4MJBbZqMAyzMKKNVFhCtmoPza8p+SC3y6rtBoaUVZMco+4142M1DQ2/LOjl5Q3g1aSD8FfYM1WqMbPrh3wfaBAU+ezL0vIw4IGCSJPs6zPJRRPRs762R4nXhCvl6+mwbpxtpwk9uc7bWBhEIluR4FRU1R/JMqv8zeEvyU175/q9BDL9G69dqAJ5tvlcaDHoD9dOAKCkuH0+YCtj1z1U/9c+AuabOpECgYEA5YDdJG7NXQGv+f/xsZwgmmvvLu+Gcvm9qbSz27gGNoYMJAhAb8jlFmgwL2NE1xYYHjePPQhL0RSDbpnVfe8Y6XRAp7g35nPfpX6dBAXB1t/FSDjM58aBTTqyVJUKYeIkFAkKZJwXuzneMbEDofw8wi/C7crupHMRTv5FsapjgKcCgYEA3E7c7mADzT5frO3TiD4aaMECwoOkgCVlWjeQ7AhT3vwOzBVtw1Cwx03ml5SGqBSUGChB+EXj7qx5rOy0g//zLdM9Suk8Gd/DpWRkupQ2qIDrS11jb3ScEPD9SBf6CAhUYSjCu3AzNanUCHtNO9D2QCu+fNxyWWINTupFXmWHg2kCgYEA2nq7izRkEhdKJG+P8enUa802jHL/hjLTaFwbIJ7mYz9nDWJBnWkdFSCoRmR1I2DoItP3az2bl3W0zTRrNhDIoW3HIyNPK/bBQHXxGeQ1LM4nq+JOxpKFgzTOkZC0qowyllQo7bBfMyAasyl1cN6EJMR9CAy49BqKrq2HQWQYh18CgYBi8rzCB7fNaDVamxrF93avE/lkWfH5aFJkOc7KZFcfMMCIoxtAfS5Y5cEq1ZfBSDTXwMUYeHOOUEL6Cvpsyvly3IyL58OJr3nVAAlJz6XY+sYzfEdb2Nj7tvFbfwFauDsFxGPqAdPOR2+nO5INyqW/XqZYuD5XrPVjO09avWkm+QKBgBkYSV3R7pLC6V1TEbydDVwPFtqQWCq+L6Z1J+uv2JnIMmoe9y9gnn2yLA+ie6rOA8ZDoFdSmWNEj+i5MnE6kY6f5wQxXq8JszJ8HUKkhMtb4SAaVHW89fK31//VjoNcNZLouG5m6/z98VWKwXB4ah0VPIyRYNMAvvK3/DYnP3HO",
			"alipayPublicCertPath": path.join(__dirname, 'alipay/alipayCertPublicKey_RSA2.crt'),
			"alipayRootCertPath": path.join(__dirname, 'alipay/alipayRootCert.crt'),
			"appCertPath": path.join(__dirname, 'alipay/appCertPublicKey.crt'),
			"sandbox": false
		},
		// 支付宝 - H5支付配置（包含：网站二维码、手机H5，需申请支付宝当面付接口权限）
		"h5": {
			"mchId": "2088641324593920",
			"appId": "2021003198688033",
			"privateKey": "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCY0Ke7rrGelu6kn87FGON+754IB4HnYKpuzWKXDGOMKXUwYiEX8tzn72gqbW1v81vPPWZaA04v8llngwLxWsVf8y7WJs5mynTDd3qf+mTUpGsTNfDbmje5MXJQHwKZlvRTMCyKgd8+wNP6y32dSfI7CIGKfk5NNmb0LOOZS2bL05g+E2rIBwIVCcEeMYCSGOPqCRsZ+R9LvRCU6toh2V7b8Bimdt/yNpFG0Wl9eZG3SC4pQCv8mKGOvoaZ04vsRSKdg4xV/NVRHVDCbIoLBQ946PG4dSUvnxGR0kgtxq9CJXM6Z1gthxEOAncBTQlI+1JzyKGkSFpuQRyXYcL/X6InAgMBAAECggEAL8UyWgpfPgtCqLXIRnbkTv8K8MmgAzuFq8OKqVtXFy6ykqBqZfkms150uqagilmR/rPb9hGIdJaW+jPLTLWqc7cqkglphlqNq7kC3VXCBXMsgcHf/FY2Sy844/D9uBOnZwXtNpMovY479e984hmGnounKysWwS5besM5lucqSFbuSRSzX34LEMmVOciA9bdYs8PWCnzU8GL4pUvHWU66Hi65pyYtWb8MYCptj3NByWa6nb/P1ZYePszfa/TZRcgP2SwtcPRZ2Jgb/sMXLC6ljWPe6RXPKWeWP8f6MV9TsDuC8lH6tXiN6J7ld97QX6ly3DRfuuAZzVDVUElZDRnRUQKBgQDM10SSZ+zw8i2h1Iv3iPB2ax7Y+gmhwsfulpFYcQOt9LMaym16mvENatbkpwonXMQX5a0vIgp3iN9gIM2ON1hIzPi6cH0IZQwqQHiisaMIjFoGvGLSAmvL2YPQVKyFAQFFcBDex2cdjaxbTt6SvlbbN1N5dre4QfPmzNE7N5W8KQKBgQC++w63u/Cy+HD1bCNiC92cTamlMwfTo+ypCBQY5ocmagul51XAQsLVTcRkDOTVuJ1nMVzPugeP8Go//by2le5+DjiKVPBQg+2a7pO5kupfCyFKA+W8sBVso7kk/zuQvMi4a4vOPUKvP1k38LTpMkmQuCMvj1I4qpm54dLHTZg1zwKBgDJsx6eWx8AkjdEppm8AGdm80vIs0xQsA9Wa4Rq5b2NyOmjc7ghhffeElnPhHuHDt03+rxxML/FvEzXxvUhGHYiGVLBooo7feRgpmMjMG8st6beAxn7WM70RxZ4SSgnPzoVOagi9Y4fl6Ujs6GONUYpTW0wqSl2kdqsZPmRqcYTJAoGBAKEA4k1/QdJ/pCsi+UllG3Tz/DrrJIQFxDRUPS0o23NFH4DD4ATvw3Uz1IdMX3bV5sziTo5JFKsCUXCVJwz+pUrcDkqAhQA72Iou65cdBj0OEwhk9L7363flJubLzZmdrdHbyMcb2iYHz91bLgkSffZlZjRoLTbcjDCq8plXDyT9AoGASdbaHg0PQO5hELl6MMKFkeDpgRQUJm7fKuV6eG/REDLtsURgrOi68BrqjMr6JRaB718F7lpLjvq+uP8eTdq9FyN2vlQGReTSs48usyey5U/mUncM0AVR7EqIYOcboaZNo7jygPAbDtoRnB094qTUFUJpgtPX7ldANYBWmt1BD1g=",
			"alipayPublicCertPath": path.join(__dirname, 'alipay/alipayCertPublicKey_RSA2.crt'),
			"alipayRootCertPath": path.join(__dirname, 'alipay/alipayRootCert.crt'),
			"appCertPath": path.join(__dirname, 'alipay/appCertPublicKey.crt'),
			"sandbox": false
		},
		// 支付宝 - 转账到支付宝等资金转出接口，其中 appCertSn 和 alipayRootCertSn 通过工具获取
		"transfer": {
			"mchId": "",
			"appId": "",
			"privateKey": "",
			"appCertSn": "",
			"alipayRootCertSn": "",
			"sandbox": false
		}
	},
	"vkspay": {
		"mchId": "", // 商户号
		"key": "" // 商户key
	}
}
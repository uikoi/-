//import plugin from './libs/index'

const install = Vue => {
	//Vue.use(plugin);
}

export default {
	install
}
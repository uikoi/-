<!-- xxxx组件 -->
<template>
	<view>
		
	</view>
</template>

<script>
export default {
	name: "vk-uview-ui-plus",
	emits: ["click"],
	props: {},
	data: function() {
		// 组件创建时,进行数据初始化
		return {};
	},
	mounted() {
		this.init();
	},
	methods: {
		// 初始化
		init() {}
	},
	watch: {
		
	},
	// 计算属性
	computed: {
		
	}
};
</script>

<style lang="scss" scoped></style>

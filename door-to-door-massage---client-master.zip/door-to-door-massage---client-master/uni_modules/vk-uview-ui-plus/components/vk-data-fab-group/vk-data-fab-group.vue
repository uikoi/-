<template>
	<view class="vk-data-fab-group">
		<view class="fab-mask" v-if="isShow" @click="_maskClick"></view>
		<view v-if="popMenu && (leftBottom||rightBottom||leftTop||rightTop) && content.length > 0" :class="{
        'vk-data-fab--leftBottom': leftBottom,
        'vk-data-fab--rightBottom': rightBottom,
        'vk-data-fab--leftTop': leftTop,
        'vk-data-fab--rightTop': rightTop
      }"
			:style="positionCom1"
		 class="vk-data-fab-view">
			<view :class="{
          'vk-data-fab__content--left': horizontal === 'left',
          'vk-data-fab__content--right': horizontal === 'right',
          'vk-data-fab__content--flexDirection': direction === 'vertical',
          'vk-data-fab__content--flexDirectionStart': flexDirectionStart,
          'vk-data-fab__content--flexDirectionEnd': flexDirectionEnd,
		  'vk-data-fab__content--other-platform': !isAndroidNvue
        }"
			 :style="{ width: boxWidth, height: boxHeight, backgroundColor: styles.backgroundColor }" class="vk-data-fab__content"
			 elevation="5">
				<view v-if="flexDirectionStart || horizontalLeft" class="vk-data-fab__item vk-data-fab__item--first" />
				<view v-for="(item, index) in content" :key="index" :class="{ 'vk-data-fab__item--active': isShow }" class="vk-data-fab__item"
				 @click="_onItemClick(index, item)">
					<view class="vk-contents" v-if="_isIcon(item.icon)" >
						<slot name="icon" :icon="currentIndex === index ? item.selectedIcon : item.icon">
							<u-icon :name="currentIndex === index ? item.selectedIcon : item.icon" size="50" :color="currentIndex === index ? styles.selectedColor : styles.color"></u-icon>
						</slot>
					</view>
					<image v-else :src="currentIndex === index ? item.selectedIcon : item.icon" class="vk-data-fab__item-image" mode="widthFix" />
					<text v-if="item.text" class="vk-data-fab__item-text" :style="{ color: currentIndex === index ? styles.selectedColor : styles.color }">{{ item.text }}</text>
				</view>
				<view v-if="flexDirectionEnd || horizontalRight" class="vk-data-fab__item vk-data-fab__item--first" />
			</view>
		</view>
		<view :class="{
		  'vk-data-fab__circle--leftBottom': leftBottom,
		  'vk-data-fab__circle--rightBottom': rightBottom,
		  'vk-data-fab__circle--leftTop': leftTop,
		  'vk-data-fab__circle--rightTop': rightTop,
		  'vk-data-fab__content--other-platform': !isAndroidNvue
		}"
		class="vk-data-fab__circle vk-data-fab__plus" :style="positionCom2" @click="_onClick"
		>
			<slot name="button" :icon="fabIcon" :rotate="isShow && content.length > 0 ? '135deg':'0deg'">
				<view class="vk-contents" v-if="_isIcon(fabIcon)">
					<u-icon :name="fabIcon" size="60" style="color:#ffffff" class="fab-circle-btn" :class="{'vk-data-fab__plus--active': isShow && content.length > 0}"></u-icon>
				</view>
				<view class="vk-contents" v-else-if="_isImage(fabIcon)">
					<image :src="fabIcon" class="fab-circle-btn image-icon" :class="{'vk-data-fab__plus--active': isShow && content.length > 0}" mode="widthFix" />
				</view>
				<view class="vk-contents" v-else>
					<view class="fab-circle-v" :class="{'vk-data-fab__plus--active': isShow && content.length > 0}"></view>
					<view class="fab-circle-h" :class="{'vk-data-fab__plus--active': isShow  && content.length > 0}"></view>
				</view>
			</slot>
		</view>
	</view>
</template>

<script>
	let platform = 'other'
	// #ifdef APP-NVUE
	platform = uni.getSystemInfoSync().platform
	// #endif

	/**
	 * Fab 悬浮按钮
	 * @description 点击可展开一个图形按钮菜单
	 * @property {Object} pattern 可选样式配置项
	 * @property {Object} horizontal = [left | right] 水平对齐方式
	 * @value left 左对齐
	 * @value right 右对齐
	 * @property {Object} vertical = [bottom | top] 垂直对齐方式
	 * @value bottom 下对齐
	 * @value top 上对齐
	 * @property {Object} direction = [horizontal | vertical] 展开菜单显示方式
	 * @value horizontal 水平显示
	 * @value vertical 垂直显示
	 * @property {Array} content 展开菜单内容配置项
	 * @property {Boolean} popMenu 是否使用弹出菜单
	 * @event {Function} trigger 展开菜单点击事件，返回点击信息
	 * @event {Function} fabClick 悬浮按钮点击事件
	 */
	export default {
		name: 'vk-data-fab-group',
		emits: ["fabClick", "trigger"],
		props: {
			pattern: {
				type: Object,
				default () {
					return {}
				}
			},
			horizontal: {
				type: String,
				default: 'left'
			},
			vertical: {
				type: String,
				default: 'bottom'
			},
			direction: {
				type: String,
				default: 'horizontal'
			},
			content: {
				type: Array,
				default () {
					return []
				}
			},
			show: {
				type: Boolean,
				default: false
			},
			popMenu: {
				type: Boolean,
				default: true
			},
			clickAutoClose: {
				type: Boolean,
				default: true
			},
			maskCloseAble: {
				type: Boolean,
				default: true
			},
			fabIcon: {
				type: String,
			},
			position:{
				type: Object,
			},
		},
		data() {
			return {
				fabShow: false,
				isShow: false,
				isAndroidNvue: platform === 'android',
				styles: {
					color: '#3c3e49',
					selectedColor: '#007AFF',
					backgroundColor: '#fff',
					buttonColor: '#007AFF'
				},
				currentIndex:""
			}
		},
		computed: {
			contentWidth(e) {
				return (this.content.length + 1) * 55 + 10 + 'px'
			},
			contentWidthMin() {
				return 55 + 'px'
			},
			// 动态计算宽度
			boxWidth() {
				return this.getPosition(3, 'horizontal')
			},
			// 动态计算高度
			boxHeight() {
				return this.getPosition(3, 'vertical')
			},
			// 计算左下位置
			leftBottom() {
				return this.getPosition(0, 'left', 'bottom')
			},
			// 计算右下位置
			rightBottom() {
				return this.getPosition(0, 'right', 'bottom')
			},
			// 计算左上位置
			leftTop() {
				return this.getPosition(0, 'left', 'top')
			},
			rightTop() {
				return this.getPosition(0, 'right', 'top')
			},
			flexDirectionStart() {
				return this.getPosition(1, 'vertical', 'top')
			},
			flexDirectionEnd() {
				return this.getPosition(1, 'vertical', 'bottom')
			},
			horizontalLeft() {
				return this.getPosition(2, 'horizontal', 'left')
			},
			horizontalRight() {
				return this.getPosition(2, 'horizontal', 'right')
			},
			positionCom1(){
				let that = this;
				let { position } = that;
				if(typeof position === "object"){
					let { windowTop, windowBottom } = uni.getSystemInfoSync();
					let obj={
						top:"initial",
						left:"initial",
						right:"initial",
						bottom:"initial",
					};
					if(position.top !== undefined){
						obj.top = `calc(${position.top} + ${windowTop}px)`;
					}else{
						obj.bottom = `calc(${position.bottom} + ${windowBottom}px)`;
					}
					if(position.left !== undefined){
						obj.left = position.left;
					}else{
						obj.right = position.right;
					}
					return obj;
				}
			},
			positionCom2(){
				let that = this;
				let { position, styles={} } = that;
				if(typeof position === "object"){
					let { windowTop, windowBottom } = uni.getSystemInfoSync();
					let obj={
						top:"initial",
						left:"initial",
						right:"initial",
						bottom:"initial",
						backgroundColor:styles.buttonColor
					};
					if(position.top !== undefined){
						obj.top = `calc(${position.top} + ${windowTop}px)`;
					}else{
						obj.bottom = `calc(${position.bottom} + ${windowBottom}px)`;
					}
					if(position.left !== undefined){
						obj.left = position.left;
					}else{
						obj.right = position.right;
					}
					return obj;
				}
			}
		},
		watch: {
			pattern(newValue, oldValue) {
				//console.log(JSON.stringify(newValue))
				this.styles = Object.assign({}, this.styles, newValue)
			}
		},
		created() {
			this.isShow = this.show
			if (this.top === 0) {
				this.fabShow = true
			}
			// 初始化样式
			this.styles = Object.assign({}, this.styles, this.pattern);

		},
		methods: {
			_onClick() {
				this.$emit('fabClick')
				if (!this.popMenu) {
					return
				}
				this.isShow = !this.isShow
			},
			open() {
				this.isShow = true
			},
			close() {
				this.isShow = false
			},
			/**
			 * 按钮点击事件
			 */
			_onItemClick(index, item) {
				let that = this;
				that.$emit('trigger', {
					index,
					item
				});
				if(that.clickAutoClose){
					that.isShow = false;
					that.currentIndex = index;
					setTimeout(function(){
						that.currentIndex = "";
					},300);
				}else{
					that.currentIndex = index;
				}
			},
			/**
			 * 获取 位置信息
			 */
			getPosition(types, paramA, paramB) {
				let that = this;
				if (types === 0) {
					return this.horizontal === paramA && this.vertical === paramB
				} else if (types === 1) {
					return this.direction === paramA && this.vertical === paramB
				} else if (types === 2) {
					return this.direction === paramA && this.horizontal === paramB
				} else {
					return this.isShow && this.direction === paramA ? this.contentWidth : this.contentWidthMin
				}
			},
			_isIcon(str){
				let that = this;
				if(str && str.indexOf("/") === -1){
					return true;
				}else{
					return false;
				}
			},
			_isImage(str){
				let that = this;
				if(str && (str.indexOf("/") > -1 || str.indexOf("http") > -1)){
					return true;
				}else{
					return false;
				}
			},
			// 点击遮罩
			_maskClick(){
				let that = this;
				let { maskCloseAble } = that;
				if(maskCloseAble){
					that.isShow = false
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vk-data-fab-group {
		/* #ifdef H5 */
		cursor: pointer;
		/* #endif */
	}
	.fab-mask{
		position: fixed;
		top:0;
		bottom: 0;
		left:0;
		right: 0;
	}
	.vk-data-fab-view {
		position: fixed;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		justify-content: center;
		align-items: center;
		z-index: 10;
	}

	.vk-data-fab--active {
		opacity: 1;
	}

	.vk-data-fab--leftBottom {
		left: 15px;
		bottom: 30px;
		/* #ifdef H5 */
		left: calc(15px + var(--window-left));
		bottom: calc(30px + var(--window-bottom));
		/* #endif */
	}

	.vk-data-fab--leftTop {
		left: 15px;
		top: 40px;
		/* #ifdef H5 */
		left: calc(15px + var(--window-left));
		top: calc(40px + var(--window-top));
		/* #endif */
	}

	.vk-data-fab--rightBottom {
		right: 15px;
		bottom: 30px;
		/* #ifdef H5 */
		right: calc(15px + var(--window-right));
		bottom: calc(30px + var(--window-bottom));
		/* #endif */
	}

	.vk-data-fab--rightTop {
		right: 15px;
		top: 40px;
		/* #ifdef H5 */
		right: calc(15px + var(--window-right));
		top: calc(40px + var(--window-top));
		/* #endif */
	}

	.vk-data-fab__circle {
		position: fixed;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		justify-content: center;
		align-items: center;
		width: 55px;
		height: 55px;
		background-color: #3c3e49;
		border-radius: 50%;
		z-index: 11;
	}

	.vk-data-fab__circle--leftBottom {
		left: 15px;
		bottom: 30px;
		/* #ifdef H5 */
		left: calc(15px + var(--window-left));
		bottom: calc(30px + var(--window-bottom));
		/* #endif */
	}

	.vk-data-fab__circle--leftTop {
		left: 15px;
		top: 40px;
		/* #ifdef H5 */
		left: calc(15px + var(--window-left));
		top: calc(40px + var(--window-top));
		/* #endif */
	}

	.vk-data-fab__circle--rightBottom {
		right: 15px;
		bottom: 30px;
		/* #ifdef H5 */
		right: calc(15px + var(--window-right));
		bottom: calc(30px + var(--window-bottom));
		/* #endif */
	}

	.vk-data-fab__circle--rightTop {
		right: 15px;
		top: 40px;
		/* #ifdef H5 */
		right: calc(15px + var(--window-right));
		top: calc(40px + var(--window-top));
		/* #endif */
	}

	.vk-data-fab__circle--left {
		left: 0;
	}

	.vk-data-fab__circle--right {
		right: 0;
	}

	.vk-data-fab__circle--top {
		top: 0;
	}

	.vk-data-fab__circle--bottom {
		bottom: 0;
	}

	.vk-data-fab__plus {
		font-weight: bold;
	}

	.fab-circle-btn {
		transform: rotate(0deg);
		transition: transform 0.3s;
	}
	.fab-circle-btn.image-icon {
		width: 60px;
		height: 60px;
		border-radius: 50%;
	}

	.fab-circle-v {
		position: absolute;
		width: 3px;
		height: 25px;
		left: 26px;
		top: 15px;
		background-color: white;
		transform: rotate(0deg);
		transition: transform 0.3s;
	}

	.fab-circle-h {
		position: absolute;
		width: 25px;
		height: 3px;
		left: 15px;
		top: 26px;
		background-color: white;
		transform: rotate(0deg);
		transition: transform 0.3s;
	}

	.vk-data-fab__plus--active {
		transform: rotate(135deg);
	}

	.vk-data-fab__content {
		/* #ifndef APP-NVUE */
		box-sizing: border-box;
		display: flex;
		/* #endif */
		flex-direction: row;
		border-radius: 55px;
		overflow: hidden;
		transition-property: width, height;
		transition-duration: 0.2s;
		width: 55px;
		border-color: #DDDDDD;
		border-width: 1rpx;
		border-style: solid;
	}

	.vk-data-fab__content--other-platform {
		border-width: 0px;
		box-shadow: 0 0 5px 2px rgba(0, 0, 0, 0.2);
	}

	.vk-data-fab__content--left {
		justify-content: flex-start;
	}

	.vk-data-fab__content--right {
		justify-content: flex-end;
	}

	.vk-data-fab__content--flexDirection {
		flex-direction: column;
		justify-content: flex-end;
	}

	.vk-data-fab__content--flexDirectionStart {
		flex-direction: column;
		justify-content: flex-start;
	}

	.vk-data-fab__content--flexDirectionEnd {
		flex-direction: column;
		justify-content: flex-end;
	}

	.vk-data-fab__item {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		width: 55px;
		height: 55px;
		opacity: 0;
		transition: opacity 0.2s;
	}

	.vk-data-fab__item--active {
		opacity: 1;
	}

	.vk-data-fab__item-image {
		width: 25px;
		height: 25px;
		margin-bottom: 3px;
	}

	.vk-data-fab__item-text {
		color: #FFFFFF;
		font-size: 12px;
	}

	.vk-data-fab__item--first {
		width: 55px;
	}
	.vk-contents{
		display: contents;
	}
</style>

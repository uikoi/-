<!-- xxxx组件 -->
<template>
	<view class="vk-data-test">
		<scroll-view class="u-drawer__scroll-view" scroll-y="true">
			<slot></slot>
		</scroll-view>
	</view>
</template>

<script>
export default {
	name: "vk-data-test",
	emits: ["click"],
	props: {},
	data: function() {
		// 组件创建时,进行数据初始化
		return {};
	},
	mounted() {
		this.init();
	},
	methods: {
		// 初始化
		init() {}
	},
	watch: {
		
	},
	// 计算属性
	computed: {
		
	}
};
</script>

<style lang="scss" scoped></style>

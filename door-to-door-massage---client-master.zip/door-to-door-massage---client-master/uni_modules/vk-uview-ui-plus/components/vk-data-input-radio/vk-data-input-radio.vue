<!-- 单选 -->
<template>
	<view class="vk-data-input-radio">
	<!-- 页面开始 -->
		<u-radio-group
			:value="valueCom"
			:modelValue="valueCom"
			:wrap="wrap"
			:width="width"
			:size="size"
			:active-color="activeColor"
			:iconSize="iconSize"
			:shape="shape"
			:disabled="disabled"
			@input="onChange"
			>
			<u-radio v-for="(item, index) in localdata" :key="index" 
				:name="item[props.value]"
				:disabled="item.disabled" 
			>
				{{ item[props.label] }}
			</u-radio>
		</u-radio-group>

	<!-- 页面结束 -->
	</view>
</template>

<script>
	export default {
		name: 'vk-data-input-radio',
		emits: ["update:modelValue", "input","change"],
		props: {
			// 表单值
			value:{

			},
			modelValue: {
			
			},
			// 数据源
			localdata:{
				type: Array,
				default () {
					return []
				}
			},
			// 提示
			placeholder:{
				Type:String,
			},
			// 是否禁用
			disabled: {
				type: Boolean,
				default: false
			},
			wrap: {
				type: Boolean,
				default: false
			},
			width:{
				Type:[String, Number],
				default: "auto"
			},
			size:{
				Type:[String, Number],
				default: 34
			},
			activeColor:{
			 	Type:String,
			 	default: "#2979ff"
			},
			iconSize:{
			 	Type:[String, Number],
			 	default: 20
			},
			shape:{
			 	Type:String,
			 	default: "circle"
			},
			props:{
				Type: Object,
				default() {
					return {
						value:'value', 
						label:'label' 
					};
				}
			}
		},
		data: function() {
			// 组件创建时,进行数据初始化
			return {
			
			};
		},
		mounted() {
			this.init();
		},
		methods: {
			// 初始化
			init(){
				
			},
			// 向父组件发送更新value事件
			_updateValue(value){
				let that = this;
				that.$emit("input",value);
				this.$emit("update:modelValue", value);
				that.$emit("change",value);
			},
			// 监听 - 值改变事件
			onChange(value){
				let that = this;
				that._updateValue(value);
			},

		},
		// 计算属性
		computed: {
			valueCom(){
				// #ifndef VUE3
				return this.value;
				// #endif
				
				// #ifdef VUE3
				return this.modelValue;
				// #endif
			},
		}
	};
</script>

<style lang="scss" scoped>

</style>

<!-- 上传 -->
<template>
	<view class="vk-data-upload" :class="quickPreview ? 'quick-preview' : ''">
		<!-- 页面开始 -->
		<view v-if="quickPreview">
			<image
				v-if="lists && lists.length"
				:src="lists[previewIndex].url"
				:style="'width: '+widthCom+';height: ' + heightCom + ';display: block;'"
				:mode="imageMode"
				@click="previewImage(lists[previewIndex].url)"
			></image>
			<view
				v-else
				class="chooseImage-view"
				:style="{
					width: widthCom,
					height: heightCom
				}"
				@click="chooseImage"
			>
				<view><image :src="defaultImage" class="default-image"></image></view>
				<view>{{ placeholder }}</view>
				<view class="upload-btn">{{ uploadText }}</view>
			</view>
		</view>
		
		<view class="header-view" v-if="showHeader">
			<view v-if="title" class="left-view">{{ title }}</view>
			<view v-if="limit > 1" class="right-view">{{ limitTitleCom }}</view>
		</view>
		
		<view style="padding: 10rpx;" v-if="(quickPreview && lists && lists.length) || !quickPreview">
			<view class="lists-view">
				<view v-for="(item, index) in lists" :key="index" class="image-item-view" style="">
					<image :src="item.url" class="image-item" @click="imageItemClick(item.url, index)"></image>
					<view class="image-mask" v-if="item.error">
						<view class="progress" @click="uploadFile">重试</view>
					</view>
					<view class="image-mask" v-else-if="item.progress < 100">
						<view class="progress">{{ item.progress }}%</view>
					</view>
					<view class="image-mask" v-else-if="quickPreview && previewIndex == index"></view>
					<view v-if="!disabled" class="delete-btn" @click="deleteImage(index)">×</view>
				</view>
				<view
					v-if="lists.length < limit"
					class="image-item-view upload-btn-sub"
					@click="chooseImage"
				>
					<view class="item-1"></view>
					<view class="item-2"></view>
				</view>
			</view>
		</view>
		<!-- 页面结束 -->
	</view>
</template>

<script>
export default {
	name: "vk-data-upload",
	emits: ["update:modelValue", "input", "on-progress", "on-success", "on-error","on-preview"],
	props: {
		// 表单值
		value: {},
		modelValue: {},
		// 提示
		placeholder: {
			Type: String
		},
		defaultImage: {
			type: String,
			default:
				"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAACUFJREFUeF7tnH+MXUUVx8+5b70v/iDRSLOuEn4IGmtFRaLiD0IBNSAkQCBEUdRt2t6ZrpY22PozZsFESMTffW/OfY92CUaNhWg0gVijglFsIlCJNCUxasS/1l8NSaO2L/vemDG7CSxv7683d3buvef++2bOnPM9nzc/7p0ZBH4arQA2OnoOHhiAhkPAADAADVeg4eFzD8AANFyBhofPPQAD0HAFGh4+9wAMQMMVaHj43AMwAA1XoOHhcw/AADRcgYaHzz0AA9BwBRoePvcADECyAkqpzQ3XqNLhSykfTgogtQcgoocAgCGoJgYPCyEuZQCqmTwbXjMANlSssA0GoMLJs+E6A2BDxQrbYAAqnDwbrpcOQOISw0YEbCOTAmut0soFQGt9ado6M5P7XKiwAuY9DSKapfq4hwEorGxFKjIAFUlUWW4yAGUpWxG7DEBFElWWmwxAWcpWxC4DUJFErXYzjuMzh8PhhqWlpaM7d+48VTQMBqCoco7rHThwYMNgMNiLiG/UWr8JAKZXXEDEx0ej0ZOI+GshxP48rjEAedRap7LLeyr6iHheBhcOhWF485YtW/6RoSwwAFlUWscyRPRNAPhEARfmhBDdtHoMQJpC6/i7UqqLiLKoC4h4YRRFR5LqMwBF1S25Xq/Xu340Gt0/YTOLg8Hg7KRJIgMwocJlVO92uy9DxEcQcaMF+10hxNxadhoFQL/fn962bdvfLIhaqgml1McQccFWI1rrc6SUfxlnrzEAKKXOBoAfSSnNEsrrRyn1LUT8uEUnrxJCPNhoAIjIzKTNjPpeIcRHLYpr3RQR/Q4A3mzLMCLujaLoy00H4KcA8N5lEW4VQnzVlsA27ezbt+/lU1NT/7RpEwDuEULMNhYApdS7zFuyVQK8Rwjxc8tCT2yOiMwQ9cTEhp5r4AEhxNWNBYCI7gSAT60SYBiG4UzWN2aWE5JoTin1d0TcYKtNrfWdUsrPNBKAgwcPvvD48eOPAcDrxwhwRAhxoS2hbdkhou8CwAdt2UPED0VRZGw+76n9KkApdSMifj9BzAUhxBZbYtuwQ0S3AMDXbdgyNswHpCiKnmwkAET0bQD4cIqYu4QQ37Al+KR2lFIXIOKvAODFk9oCgENCiCvWslPrHqDT6ZzXarXMu/DT0oT0bYcyEX0eAL6Y5neG3zcJIY41EgCl1G5EzLrcG4RheIZPk0Kl1GFEvChDkscWQcQboyi6L6l+rXsAIjLLvMuyCqi1flRK+bas5V2UI6KnAeDMAm09KIS4Kq1ebQHodruXBEGQ++SR1vpuKeW2NOFc/q6U2omImeYoWmuzEWSvlPKeLD7WFgCl1F2IeGsWEVaXMe/hoyjqFKlbVh0iulxrfbuZ0QPAS8a08wcA+NmJEyf27tmz599Z/aglAPv37z9tMBgcybiFaqxWvk0KV5ycn5+fmp6ePh8Rz9dabwiC4MjS0tJTc3Nzi1mT/uxytQSg2+3eFATBd4oIslJHa/3fdrt9lk+TwkniadQqwOKbtMNCiHeWIbwvNmvXA8Rx/Dqt9e8B4AWWRCYhROF9eZZ8KM1M7QAgok8CwNhv3xOomGmH7QT2161qHQEwr1DfbVtRXyeFk8ZZKwD6/f5lw+GwrG/8J8IwPLduk8JaAUBEXwOAXZP+KxLqm6NXF5do37np2gCwsLDw0lOnTplPnmeUrGLiNuuS27ZuvjYA9Hq9m0ej0b3WFRpvsDaTwtoAEMfx/Vrr6x0BAGVNCuM4flEURf9xFUctAOj1eptGo9FRV6Itt/NMGIavtTkpjOP4LeZ9fxiGszbtJulSCwCUUp9GxDscA2B6gV9KKa3chB7H8U0m+QBwLgCkXs9mK9ZaABDH8WNa6/Xa3DnppBCJyCTe7AB69uNknlF5AOI4fp/W+pCtf0RBO4WS1el0NrZaLZP8G8a12263Z2ZnZwt95csaR+UBICLz3X5H1oDLKpd3UqiUug4RTfLfkOBT6UNBpQGI4/h0rfVTAHB6WYnNaldr/a92u70xy+SNiMwhDZP8qQz2C/UuGez+v0ilASAic97tQNZgHZRL/MeaE8qIeBsAfCSPL4h4VhRFf81TJ2vZqgPwAAC8P2uwjsqNnRQS0RXLW7reWsCP0oaCygJQ0iHKArkZW+U53XYcx7uWl3ip5xMSHChlKKgyAF8AANOdevmYSSEAHAuC4HatdWTDyampqdds3br1jzZsrdioLABxHB/VWm+yKYZNW2Z7dhAEx7TWl1i0a30oqCQARGTGfTP+N/GxOhRUFQAz8x9740VDiEg875dHg8oB0Ol0XtFqtcw4aOPkbB6tfCprbSioHABKqQgRyadsrIcviHhLFEXm0quJnsoBkPfA50TqeF45CIILtm/fPtF9QpUCYPl7+eOe58WlexMPBZUCgIi+BABjLztyqbpnbe0RQtxV1KeqAfAnAHh10WDrWk9r/XYp5W+LxFcZALrd7rVBEPywSJANqFN4KKgMABYPfNaSB0T8XBRFZojM9VQCAKXUqxDRXJXSyhVdwwoj4sVRFK2+ETVRhUoAYPvevBpzkXsoqAoAvwGAd9Q4cdZC01rfJqWcz2rQewD6/f5Fw+HwcNaAuByY7eqXSyl/kUUL7wFwcOAzi05VK/PI4uLi5vn5+aU0x70GwFyINDMz87TW+pVpgfDvz1PgDiHEZ9N08RoApdQHEPF7aUHw72sqcKUQ4idJ+ngNABH9AACu4wQXUwARHwWAzUmHTb0FoN/vnzMcDv9cLHSutaKA1vorUkpzb9LYx1sA1uvAZx3RGY1G1+zYsePH42LzGQArp27rmNAiMZ08efKJ3bt3P7O6rrcAFAmS6+RXgAHIr1mtajAAtUpn/mAYgPya1aoGA1CrdOYPhgHIr1mtaqwrAOYypFqpWd1g1lpyp+4vwLSYiegh8zoyrRz/7qUCDICXaXHnFAPgTmsvW2IAvEyLO6cYAHdae9kSA+BlWtw5NTkAZp3pzl9uybYCUsrEpXrqMtC2Q2zPLwUYAL/y4dwbBsC55H41yAD4lQ/n3jAAziX3q0EGwK98OPeGAXAuuV8NMgB+5cO5NwyAc8n9apAB8Csfzr1hAJxL7leDDIBf+XDuDQPgXHK/GmQA/MqHc28YAOeS+9UgA+BXPpx7wwA4l9yvBhkAv/Lh3Jv/Ad5cn9t5roAZAAAAAElFTkSuQmCC"
		},
		width: {
			type: [String, Number],
			default: 200
		},
		height: {
			type: [String, Number]
		},
		// 是否显示快速预览
		quickPreview: {
			type: Boolean,
			default: false
		},
		// 图片显示模式
		imageMode: {
			type: String,
			default: "aspectFill"
		},
		// 是否禁用
		disabled: {
			type: Boolean,
			default: false
		},
		// 是否在点击预览图后展示全屏图片预览
		previewFullImage: {
			type: Boolean,
			default: true
		},
		
		showHeader: {
			type: Boolean,
			default: false
		},
		needSave: {
			type: Boolean,
			default: false
		},
		title: {
			type: String,
			default: "上传图片"
		},
		// 最大上传数量
		limit: {
			type: Number,
			default: 99
		},
		// 服务供应商
		provider: {
			type: String
		},
		// 选择图片按钮的提示文字
		uploadText: {
			type: String,
			default: "选择图片"
		},
		// 所选的图片的尺寸, 可选值为original compressed
		sizeType: {
			type: Array,
			default() {
				return ["original", "compressed"];
			}
		},
		// 所选的图片的来源
		sourceType: {
			type: Array,
			default() {
				return ["album", "camera"];
			}
		},
		
		maxSize: {
			type: [String, Number],
			default: 999999999
		}
	},
	data: function() {
		// 组件创建时,进行数据初始化
		return {
			// 预览图
			previewIndex: 0,
			lists: []
		};
	},
	mounted() {
		this.init();
	},
	methods: {
		// 初始化
		init() {
			let that = this;
			let { valueCom: value, vk, limit } = that;
			if (vk.pubfn.isNull(value) && limit > 1) {
				that._updateValue([]);
			}
		},
		// 向父组件发送更新value事件
		_updateValue(value) {
			let that = this;
			let { limit } = that;
			if (limit == 1) {
				if (typeof value === "object") {
					value = value[0];
				}
			}
			that.$emit("input", value);
			that.$emit("update:modelValue", value);
		},
		// 选择图片
		chooseImage() {
			let that = this;
			let { sizeType, sourceType, lists, limit, maxSize, disabled } = that;
			if (lists.length >= limit) {
				return false;
			}
			if (disabled) {
				return false;
			}
			uni.chooseImage({
				count: limit, //默认9
				sizeType, //可以指定是原图还是压缩图，默认二者都有
				sourceType, //从相册选择
				success: function(res) {
					res.tempFiles.map((val, index) => {
						if (val.size > maxSize) {
							that.$emit("on-oversize", val, that.lists, that.index);
							uni.showToast({
								title: "超出允许的文件大小",
								icon: "none"
							});
						}
						if (lists.length >= limit) {
							that.$emit("on-exceed", val, that.lists, that.index);
							uni.showToast({
								title: "超出最大允许的文件个数",
								icon: "none"
							});
							return;
						}
						lists.push({
							url: val.path,
							progress: 0,
							error: false,
							file: val
						});
					});
					that.lists = JSON.parse(JSON.stringify(lists));
					that.uploadFile();
				}
			});
		},
		// 删除图片
		deleteImage(index) {
			let that = this;
			let { previewIndex = 0, vk, valueCom: value, limit } = that;
			vk.confirm("确定删除吗？","删除提示","确定","取消",function(res){
				if(res.confirm){
					if (vk.pubfn.isNull(value)) {
						that.lists.splice(index,1);
					}
					if (previewIndex >= that.lists.length - 1) {
						that.previewIndex = 0;
					}
					if (limit > 1) {
						value.splice(index, 1);
					} else {
						value = "";
					}
					that._updateValue(value);
				}
			});
		},
		// 监听内部文件变化 - 实现自定义上传
		async uploadFile() {
			let that = this;
			let { provider, vk, lists:list } = that;
			if (!provider) {
				let config = vk.callFunctionUtil.getConfig();
				let aliyunOSS = vk.pubfn.getData(config, "service.aliyunOSS");
				if (aliyunOSS && aliyunOSS.isDefault) {
					provider = "aliyun";
				} else {
					provider = "unicloud";
				}
			}
			let tasks = [];
			list.map((item, index) => {
				if (item.progress < 100) {
					if (provider === "unicloud") {
						tasks.push(that.beforeUpload_unicloud(index, list));
					} else if (provider === "aliyun") {
						tasks.push(that.beforeUpload_aliyunoss(index, list));
					}
				}
			});
			await Promise.all(tasks);
			let images = [];
			that.lists.map((item, index) => {
				images.push(item.url);
			});
			that._updateValue(images);
		},
		// 上传到unicloud
		beforeUpload_unicloud(index, list) {
			let that = this;
			let { vk, limit, needSave } = that;
			let tempFilePath = list[index].url;
			let file = list[index].file;
			return vk.callFunctionUtil.uploadFile({
				filePath: tempFilePath,
				fileType: "image",
				provider: "unicloud",
				file,
				needSave,
				onUploadProgress: function(res) {
					if (res.progress > 0) {
						if (list[index]) {
							list[index].progress = res.progress;
							that.$emit("on-progress", res, index, list);
						}
					}
				},
				success: function(res) {
					// 上传成功
					let url = res.fileID;
					list[index].response = "ok";
					list[index].progress = 100;
					list[index].error = false;
					list[index].url = url;
					that.$emit("on-success", res, index, list);
					let images = that.valueCom;
					if (limit > 1) {
						if (!images || images.length == 0) {
							images = [];
						}
						images.push(url);
					} else {
						images = url;
					}
					//that._updateValue(images);
				},
				fail: function(res) {
					// 上传失败
					list[index].error = true;
					that.$emit("on-error", res, index, list);
				}
			});
		},
		// 上传到阿里云oss
		beforeUpload_aliyunoss(index, list) {
			let that = this;
			let { limit, vk, needSave } = that;
			let tempFilePath = list[index].url;
			let file = list[index].file;
			return vk.callFunctionUtil.uploadFile({
				filePath: tempFilePath,
				fileType: "image",
				provider: "aliyun",
				index,
				file,
				needSave,
				onUploadProgress: function(res) {
					if (res.progress > 0) {
						if (list[index]) {
							list[index].progress = res.progress;
							that.$emit("on-progress", res, index, list);
						}
					}
				},
				success: function(res) {
					// 上传成功
					let url = res.fileID;
					list[index].response = res;
					list[index].progress = 100;
					list[index].error = false;
					that.$emit("on-success", res, index, list);
					let images = that.valueCom;
					if (limit > 1) {
						if (!images || images.length == 0) {
							images = [];
						}
						images.push(url);
					} else {
						images = url;
					}
					that._updateValue(images);
				},
				fail: function(res) {
					// 上传失败
					that.$emit("on-error", res, index, list);
				}
			});
		},
		// 图片预览
		previewImage(url, index){
			let that = this;
			let { previewIndex, lists, previewFullImage } = that;
			if (index == undefined) index = previewIndex;
			if (!previewFullImage){
				that.$emit('on-preview', url, lists, index);
				return;
			} 
			const images = lists.map(item => item.url || item.path);
			uni.previewImage({
				urls: images,
				current: url,
				success: () => {
					that.$emit('on-preview', url, lists, index);
				},
				fail: () => {
					uni.showToast({
						title: '预览图片失败',
						icon: 'none'
					});
				}
			});
		},
		// 图片item点击
		imageItemClick(url, index){
			let that = this;
			let { quickPreview, previewFullImage } = that;
			that.previewIndex = index;
			if (!quickPreview && previewFullImage) {
				that.previewImage(url, index);
			}
		}
	},
	// 监听器
	watch: {
		valueCom: {
			immediate: true,
			handler: function(newVal, oldVal) {
				let that = this;
				let lists = [];
				if (newVal) {
					if (that.limit == 1) {
						lists.push({
							url: newVal,
							progress: 100,
							error: false
						});
					} else {
						newVal.map((item, index) => {
							lists.push({
								url: item,
								progress: 100,
								error: false
							});
						});
					}
				}
				that.lists = JSON.parse(JSON.stringify(lists));
			}
		}
	},
	// 计算属性
	computed: {
		valueCom() {
			// #ifndef VUE3
			return this.value;
			// #endif

			// #ifdef VUE3
			return this.modelValue;
			// #endif
		},
		widthCom(){
			let width = this.width;
			return `${Number(width)}rpx`;
		},
		heightCom() {
			let height = this.height;
			return `${Number(height)}rpx`;
		},
		limitTitleCom() {
			let that = this;
			let { limit } = that;
			let str = "";
			if (limit > 1) {
				let { valueCom: value } = that;
				if (!value) value = [];
				let length = value.length;
				str = `${length} /  ${limit}`;
			}
			return str;
		}
	}
};
</script>

<style lang="scss" scoped>
.vk-data-upload {
	width: 100%;
	text-align: left;
	.chooseImage-view {
		color: #989898;
		background-color: #f8f8fa;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
	}
	.upload-btn {
		border: 1px solid #52a0d5;
		color: #52a0d5;
		background-color: #ffffff;
		border-radius: 8rpx;
		padding: 20rpx 60rpx;
		margin-top: 20rpx;
		line-height: normal;
	}
	.image-mask {
		position: absolute;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.4);
		border-radius: 8rpx;
		top: 0;
		left: 0;
		z-index: 2;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.image-item-view {
		position: relative;
		display: inline-block;
		margin: 10rpx;
		width: 150rpx;
		height: 150rpx;
		.image-item {
			width: 100%;
			height: 100%;
			border-radius: 10rpx;
		}
	}
	.delete-btn {
		position: absolute;
		right: 10rpx;
		top: 10rpx;
		font-size: 30rpx;
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		text-align: center;
		line-height: 36rpx;
		z-index: 3;
		background-color: #565656;
		color: #ffffff;
	}
	.progress {
		font-size: 24rpx;
		width: 70rpx;
		height: 70rpx;
		background-color: #ffffff;
		border-radius: 50%;
		text-align: center;
		line-height: 70rpx;
	}
	.upload-btn-sub {
		width: 150rpx;
		height: 150rpx;
		background-color: #eff8ff;
		border: 1px solid #c3e1ed;
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		.item-1 {
			position: absolute;
			width: 50%;
			border-bottom: 2px solid #489cd3;
		}
		.item-2 {
			position: absolute;
			border-left: 2px solid #489cd3;
			height: 50%;
		}
	}
	.lists-view {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
	}
	.default-image {
		width: 128rpx;
		height: 128rpx;
	}
	.header-view {
		padding: 10rpx 20rpx;
		display: flex;
	}
	.left-view {
		width: 70%;
	}
	.right-view {
		width: 30%;
		text-align: right;
	}
}
.vk-data-upload.quick-preview {
	.delete-btn {
		background-color: #ffffff;
		color: #000000;
	}
}
</style>

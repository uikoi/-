<script>
import config from "@/app.config.js"
// #ifdef APP-PLUS
import upAPP from "@/pages/uni-upgrade-center-app/utils/check-update.js"
// #endif
export default {
	methods: {
		// 初始化
		init() {
			// if (vk.checkToken()) {
			// 	this.lockInviter() // 分享人锁定
			// }
			// #ifdef APP-PLUS
			upAPP()
			// #endif
			// #ifdef H5
			vk.myfn.vksPayInit()
			// #endif
		},
		// 获取商家信息
		getMchInfo() {
			vk.callFunction({
				url: "client/pub.getMchInfo",
				debug: false,
				data: {},
				success: function (data) {
					vk.setVuex("$user.mchInfo", data.mchInfo)
				}
			})
		},
		// 分享人锁定
		lockInviter() {
			let code = vk.getVuex("$user.inviteCode")
			if (code) {
				vk.callFunction({
					url: "client/salesman.pub_addUserLocking",
					data: {
						invite_code: code
					},
					needAlert: false,
					success: data => {
						//if (config.debug && data.msg) vk.toast(data.msg);
						vk.setVuex("$user.inviteCode", "")
					},
					fail: data => {
						vk.setVuex("$user.inviteCode", "")
					}
				})
			}
		}
	},
	// 监听 - 页面404
	onPageNotFound: function (e) {
		uni.redirectTo({
			url: config.error.url
		})
	},
	onLaunch: function (options) {
		if (config.debug) console.log("App Launch")
		let { query } = options
		if (query.scene) {
			let scene = decodeURIComponent(decodeURIComponent(query.scene))
			let splitArr = scene.split(":")
			let key = splitArr[0]
			if (key == 1) {
				let val = splitArr[1]
				query.inviteCode = val
			}
		}
		let { inviteCode } = query
		if (inviteCode && !vk.getVuex("$user.inviteCode")) {
			vk.setVuex("$user.inviteCode", inviteCode)
		}
		this.getMchInfo() // 获取商家信息
		this.init()
		// #ifdef APP-PLUS
		let aaabbb = vk.getStorageSync("aaabbb")
		if (aaabbb) {
			plus.navigator.closeSplashscreen()
		} else {
			uni.reLaunch({
				url: "/pages/index/order",
				success() {
					plus.navigator.closeSplashscreen()
				}
			})
		}
		// #endif
	}
}
</script>

<style lang="scss">
/*每个页面公共css */
@import "./static/vk-icon.css";
/* 动态单色字体库 */
@import "./static/vk-mall-icon.css";
/* 彩色字体库 */
@import "./uni_modules/vk-uview-ui/index.scss";
/* uview样式库 */
@import "./common/css/app.scss";
/* 自定义应用样式库 */
</style>

<!-- 浮球 -->
<template>
	<view class="vk-mall-contact-service" v-if="complete">
		<!-- 返回按钮 -->
		<view
			class="ball-btn left-btn"
			@click="vk.navigateTo('/pages/service-center/service-center');"
			:style="{
				bottom: '500rpx',
				zIndex: zIndex
			}"
		>
			<u-icon name="vk-icon-service" color="#FFFFFF" size="38"></u-icon>
		</view>
	</view>
</template>

<script>
export default {
	name: "vk-mall-contact-service",
	props: {
		zIndex: {
			type: [Number],
			default: 900
		},
	},
	data: function() {
		// 组件创建时,进行数据初始化
		return {
			complete: false
		};
	},
	mounted: function() {
		setTimeout(() => {
			this.complete = true;
		}, 100);
	},
	methods: {

	},
	computed: {

	}
};
</script>

<style lang="scss" scoped>
.vk-mall-contact-service {
	.ball-btn {
		width: 80rpx;
		height: 80rpx;
		position: fixed;
		border-radius: 50%;
		background-color: rgba(0, 0, 0, 0.6);
		display: flex;
		justify-content: center;
		align-items: center;
		color: #ffffff;
		z-index: 900;
	}
	.left-btn {
		left: 40rpx;
	}
	.right-btn {
		right: 40rpx;
	}
}
</style>

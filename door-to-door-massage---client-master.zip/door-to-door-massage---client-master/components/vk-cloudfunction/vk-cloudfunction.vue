<!-- 
云函数调用组件
此组件一般用于页面的详情页、列表页的数据快速获取
 -->
<template>
	<view></view>
</template>

<script>
export default {
	name: "vk-cloudfunction",
	emits: ["update:modelValue", "input", "load", "error", "update:pageIndex", "update:status"],
	props: {
		value: {},
		modelValue: {},
		action: {
			Type: String,
			default: ""
		},
		formData: {
			Type: Object,
			default: function() {
				return {};
			}
		},
		columns: {
			Type: Array,
			default: function() {
				return [];
			}
		},
		sortRule: {
			Type: Array,
			default: function() {
				return [];
			}
		},
		loading: {
			Type: [Boolean, Object],
			default: true
		},
		needAlert: {
			Type: Boolean,
			default: true
		},
		loadingTitle: {
			Type: String,
			default: "请求中..."
		},
		pagination: {
			Type: Boolean,
			default: false
		},
		// 
		pageIndex: {
			Type: Number,
			default: 1
		},
		// 每页显示数量
		pageSize: {
			Type: Number,
			default: 20
		},
		// 分页策略选择。值为 add 代表下一页的数据追加到之前的数据中，常用于滚动到底加载下一页；值为 replace 时则替换当前data数据，常用于PC式交互，列表底部有页码分页按钮，默认值为add
		pageData: {
			Type: String,
			default: "add"
		},
		status: {
			Type: String,
			default: "loadmore"
		},
		idKey: {
			Type: String,
			default: "_id"
		},
		
	},
	data() {
		return {
			_loading: false
		};
	},
	mounted() {
		this.init();
	},
	// 函数
	methods: {
		// 初始化
		init() {
			
		},
		_input(value) {
			let that = this;
			that.$emit("input", value);
			that.$emit("update:modelValue", value);
		},
		load(obj){
			setTimeout(() => {
				this._load(obj);
			}, 0);
		},
		// 请求云函数
		_load(obj = {}) {
			let that = this;
			let {
				action,
				loading = true,
				loadingTitle,
				formData,
				columns,
				sortRule,
				needAlert,
				pagination,
				pageIndex,
				pageSize,
				pageData,
				valueCom,
				idKey
			} = that;
			let dataJson = {
				// 分页数据
				pagination: {
					pageIndex,
					pageSize
				},
				// 查询表单数据源，可在此设置默认值
				formData,
				// 查询匹配规则 fieldName:指定数据库字段名,不填默认等于key
				columns,
				// 排序规则
				sortRule
			};
			let isAddPagination = pageData == "add" && pagination ? true : false;
			if (isAddPagination) that.$emit("update:status", "loading");
			that._loading = true;
			vk.callFunction({
				url: action,
				title: loadingTitle,
				loading,
				needAlert,
				data: dataJson,
				success: function(data) {
					that._loading = false;
					let value; // 最终显示的数据
					let returnList = data.rows || []; // 请求返回的数据
					let currentList = valueCom.rows || []; // 当前数据
					if (isAddPagination) {
						// 分页
						let status = "";
						if (pageIndex > 1) {
							// 翻页
							if (returnList.length > 0) {
								// 有数据时，数据合并
								currentList = vk.pubfn.arr_concat(currentList, returnList, idKey);
							} else {
								pageIndex--;
								that.$emit("update:pageIndex", pageIndex);
							}
						} else if (pageIndex == 1) {
							// 第一页
							currentList = returnList;
						}
						status = data.hasMore ? "loadmore" : "nomore";
						data.rows = currentList;
						that.$emit("update:status", status);
					}
					value = data;
					that.$emit("load", value);
					that._input(value);
				},
				fail: function(data) {
					that._loading = false;
					that.$emit("error", data);
				}
			});
		},
		toPage(pageIndex = 1){
			if (pageIndex < 1) pageIndex = 1;
			let that = this;
			if (!that._loading) {
				that.pageIndex = pageIndex;
				that.load();
			}
		},
		nextPage(){
			let that = this;
			if (!that._loading) {
				that.pageIndex++;
				that.load();
			}
		},
	},
	// 监听属性
	watch: {

	},
	// 计算属性
	computed: {
		valueCom() {
			// #ifndef VUE3
			return this.value;
			// #endif

			// #ifdef VUE3
			return this.modelValue;
			// #endif
		}
	}
};
</script>

<style lang="less"></style>

<template>
	<view class="banner" :style="'border-radius: ' + br + 'rpx'">
		<u-swiper
			bg-color="transparent"
			:list="list"
			:height="390"
			:border-radius="br"
			@click="swiperClick"
		></u-swiper>
	</view>
</template>

<script>
export default {
	name: "banner",
	props: {
		// 查询条件 id列表
		ids: { Type: Array },
		// 查询条件name
		name: { Type: String },
		br: { Type: Number, default: 12 }
	},
	data() {
		return {
			list: []
		}
	},
	methods: {
		// 初始化
		init() {
			let that = this
			let { vk, name, ids } = that
			let actionData = { name, ids }
			// 请求带缓存
			vk.myfn.callFunctionForCache({
				url: "client/pub.getComponentsList",
				loading: { name: "loading", that },
				data: actionData,
				success: res => {
					that.list = res.list
					that.$emit("qlist")
				}
			})
		},
		swiperClick(e) {
			if (this.list[e].type === 3) {
				vk.navigateTo(`/pages/web-view/report`)
			} else if (this.list[e].type === 4) {
				vk.navigateTo(this.list[e].url)
			} else {
				vk.navigateTo(`/pages/web-view/web-view?id=${this.list[e]._id}`)
			}
		}
	}
}
</script>

<style lang="scss" scoped>
.banner {
	height: 390rpx;
	position: relative;
}
</style>

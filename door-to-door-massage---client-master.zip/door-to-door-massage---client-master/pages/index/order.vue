<template>
	<view class="app app-bg">
		<z-paging
			show-refresher-update-time
			show-refresher-when-reload
			v-model="orderList"
			ref="paging"
			:auto-clean-list-when-reload="false"
			@query="queryList"
		>
			<view class="top" slot="top">
				<u-tabs
					inactive-color="#999999"
					active-color="#24C388"
					font-size="28"
					duration="0.2"
					height="70"
					:list="list"
					:current="current"
					:is-scroll="false"
					@change="change"
				></u-tabs>
			</view>
			<view slot="empty" v-if="!isLogin">
				<u-empty text="请先前往登录" mode="permission"></u-empty>
			</view>
			<block v-for="item in orderList" :key="item._id">
				<order-item
					:item="item"
					@cancel="cancel"
					@confirm="confirm"
					@timeout="timeout"
					@appraise="appraise"
				></order-item>
			</block>
		</z-paging>
		<cancel-pop ref="cp" v-if="show" @hide="hide" @send="cancelOrder"></cancel-pop>
	</view>
</template>

<script>
var vk = uni.vk // vk依赖
import orderItem from "./components/order-item"
import cancelPop from "@/pages/order/components/cancel-pop"

export default {
	components: { orderItem, cancelPop },
	data() {
		return {
			// 分类
			list: [
				{ name: "全部", index: "all" },
				{ name: "服务中", index: 5 },
				{ name: "待确认", index: 6 },
				{ name: "待评价", index: 7 },
				{ name: "已完成", index: 8 }
			],
			current: 0,
			// 订单列表
			orderList: [],

			show: false,
			isLogin: false
		}
	},
	onLoad() {
		vk.setStorageSync("aaabbb", true)
	},
	onShow() {
		// fresh为1时刷新页面
		let fresh = vk.getStorageSync("fresh")
		if (this.$refs.paging && fresh === 1) {
			this.$refs.paging.reload()
		}
		vk.setStorageSync("fresh", 2)
	},
	methods: {
		// 切换分类
		change(e) {
			this.current = e
			this.$refs.paging.reload()
		},
		// 查询服务订单列表
		queryList(pageIndex, pageSize) {
			this.isLogin = vk.checkToken()
			if (!this.isLogin) {
				return this.$refs.paging.complete(false)
			}
			const { list, current } = this
			vk.callFunction({
				url: "client/order.queryMyServiceOrder",
				data: { pageSize, pageIndex, status: list[current].index }
			}).then(res => {
				this.cods = res.cods
				this.$refs.paging.complete(res.rows)
			})
		},
		// 取消
		cancel(item) {
			if (item.pay_status === 0) {
				this.cancelOrder(item._id)
			} else {
				this.show = true
				this.$nextTick(() => {
					this.$refs.cp.init({ cper: this.cods, ...item })
				})
			}
		},
		hide() {
			this.show = false
		},
		cancelOrder(oid) {
			this.show = false
			vk.callFunction({
				url: "client/order.cancelMyOrder",
				title: "取消中...",
				data: { oid }
			}).then(() => {
				vk.toast("取消成功")
				this.$refs.paging.reload()
			})
		},
		timeout() {
			this.$refs.paging.reload()
		},
		// 确认
		confirm(item) {
			vk.confirm("确认已完成服务？", res => {
				if (!res.confirm) return
				vk.callFunction({
					url: "client/order.confirmMyOrder",
					title: "提交中...",
					data: { oid: item._id }
				}).then(() => {
					vk.toast("提交成功", "none", 800, () => {
						this.$refs.paging.reload()
					})
				})
			})
		},
		// 评价
		appraise(item) {
			vk.navigateTo(`/pages/order/appraise?id=${item._id}`)
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	height: 100vh;
	background: linear-gradient(135deg, #eafff8 0%, #e7fcff 100%) no-repeat;
}
</style>

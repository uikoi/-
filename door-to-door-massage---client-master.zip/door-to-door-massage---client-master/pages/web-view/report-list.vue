<template>
	<z-paging
		show-refresher-update-time
		show-refresher-when-reload
		bg-color="#f5f5f5"
		class="app app-bg"
		v-model="list"
		ref="paging"
		@query="queryList"
	>
		<view class="item" v-for="i in list" :key="i._id">
			<view class="left">
				<text class="tit">{{ i.content }}</text>
				<text>{{ vk.pubfn.timeFormat(i._add_time, "yyyy-MM-dd hh:mm") }}</text>
			</view>
			<view class="succ" v-if="i.read">已处理</view>
			<view class="wait" v-else>待处理</view>
		</view>
	</z-paging>
</template>

<script>
var vk = uni.vk // vk依赖

export default {
	data() {
		return {
			list: []
		}
	},
	methods: {
		// 查询列表
		queryList(pageIndex, pageSize) {
			vk.callFunction({
				url: "client/user.getReportList",
				data: { pageIndex, pageSize }
			}).then(res => {
				this.$refs.paging.complete(res.rows)
			})
		}
	}
}
</script>

<style lang="scss" scoped>
.item {
	display: flex;
	align-items: center;
	justify-content: space-between;
	background-color: #fff;
	padding: 24rpx 20rpx;
	margin: 20rpx;
	border-radius: 12rpx;
	font-size: 26rpx;

	.left {
		width: 70%;
		display: flex;
		flex-direction: column;
		padding-right: 24rpx;
		color: #999;

		.tit {
			font-size: 28rpx;
			color: #333;
			text-overflow: ellipsis;
			white-space: nowrap;
			overflow: hidden;
			margin-bottom: 10rpx;
		}
	}

	.succ {
		color: #67c23a;
	}

	.wait {
		color: #e6a23c;
	}
}
</style>

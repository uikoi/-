<template>
	<view class="app">
		<web-view v-if="url" :src="url"></web-view>
		<u-parse v-if="content" :tag-style="style" :html="content"></u-parse>
	</view>
</template>

<script>
var vk = uni.vk

export default {
	data() {
		return {
			url: "",
			content: "",
			// 富文本样式
			style: {
				p: "font-size: 28rpx;line-height: 40rpx",
				span: "font-size: 28rpx;line-height: 40rpx"
			}
		}
	},
	onLoad(options = {}) {
		vk = uni.vk
		this.options = options
		this.init(options)
	},
	methods: {
		// 页面数据初始化函数
		async init(options) {
			const res = await vk.callFunction({
				url: "client/pub.getBannerInfo",
				title: "获取中...",
				data: { _id: options.id }
			})
			if (res.code !== 0) return
			if (res.data.type == 1) {
				this.url = decodeURIComponent(res.data.url)
			}
			if (res.data.type == 2) {
				this.content = res.data.content
			}
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	height: 100vh;
	/* #ifdef H5 */
	height: calc(100vh - 88rpx);
	/* #endif */
	background-color: #f5f5f5;
	padding: 20rpx;
}
</style>

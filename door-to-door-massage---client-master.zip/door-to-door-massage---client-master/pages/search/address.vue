<template>
	<view>
		<city-select ref="citys" :isSearch="true" :formatName="formatName" :activeCity="activeCity" :obtainCitys="obtainCitys"
			@trigger="trigger"></city-select>
	</view>
</template>

<script>
import citys from "@/common/js/citys.js"
import citySelect from "@/components/city-select/city-select.vue"

export default {
	data() {
		return {
			//需要构建索引参数的名称（注意：传递的对象里面必须要有这个名称的参数）
			formatName: "title",
			//当前城市
			activeCity: {},
			//显示的城市数据
			obtainCitys: [],
			// 选择城市
			address: null
		}
	},
	components: { citySelect },
	onLoad(opt) {
		//修改当前城市
		if (opt.city) {
			let item = vk.pubfn.getListItem(citys, "cityName", opt.city)
			if (item) this.activeCity = item
		}
		this.init(opt)
	},
	methods: {
		async init(opt) {
			//修改数据格式
			this.formatName = "cityName"
			//修改构建索引数据
			let res = await vk.callFunction({
				url: "client/pub.queryAlreadyTownList",
				title: "请求中..."
			})
			// 查出所有在res.list中的城市
			// res.list格式：['合肥市', '蚌埠市', '六安市']
			// citys格式：[{cityCode: "340100", cityName: "合肥市"}]
			let arr = []
			for (let i = 0; i < res.list.length; i++) {
				let item = vk.pubfn.getListItem(citys, "cityName", res.list[i])
				if (item) arr.push(item)
			}
			console.log(arr)
			this.obtainCitys = arr
		},
		trigger(city) {
			vk.setStorageSync("addr", city.cityName)
			vk.toast(`已选择${city.cityName}`, "none", 500, () => {
				uni.$emit("cityChange", city.cityName)
				vk.navigateBack()
			})
		}
	}
}
</script>

<style lang="scss" scoped>
.btns {
	position: fixed;
	bottom: 20rpx;
	left: 60rpx;
	right: 60rpx;
	height: 80rpx;
	box-shadow: 6rpx 10rpx 12rpx rgba(103, 194, 255, 0.3);
	background-color: #67c2ff;
	border-radius: 60rpx;
	text-align: center;
	line-height: 80rpx;
	color: #fff;
}
</style>

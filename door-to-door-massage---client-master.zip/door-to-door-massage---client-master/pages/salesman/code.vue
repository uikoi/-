<template>
	<view class="page_bg">
		<image
			src="https://mp-d0bdc000-db91-44a8-852b-e6f607a7ca19.cdn.bspapp.com/inv_title.png"
			class="title"
		></image>
		<view class="main">
			<view class="qrcode" v-if="url">
				<vk-data-qrcode ref="qrc" :text="url" :size="346"></vk-data-qrcode>
			</view>
		</view>
		<!-- <view class="btn" @tap="longtap">保存二维码图片</view> -->
	</view>
</template>

<script>
export default {
	data() {
		return {
			url: "",

			show: false
		}
	},
	onLoad() {
		this.init()
	},
	methods: {
		init() {
			vk.callFunction({
				url: "user/kh/getWxOffAccountCode",
				title: "获取中..."
			}).then(res => {
				this.url = res.url
			})
		},
		longtap() {
			this.$refs.qrc._saveCode()
		}
	}
}
</script>

<style lang="scss" scoped>
.page_bg {
	min-height: 100vh;
	background: linear-gradient(221deg, #ddfff9 0%, #ffffff 46%, #e8efff 74%, #deffec 100%);
	background-size: 100% 100%;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
}

.title {
	width: 308rpx;
	height: 87rpx;
}

.main {
	width: 628rpx;
	height: 616rpx;
	background: url("https://mp-d0bdc000-db91-44a8-852b-e6f607a7ca19.cdn.bspapp.com/inv_bg.png")
		center no-repeat;
	background-size: 100% 100%;
	margin: 44rpx 0 36rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}

.btn {
	color: #fff;
	height: 80rpx;
	border-radius: 100rpx;
	background-color: #24c388;
	margin: 0 84rpx;
	width: calc(100vw - 168rpx);
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>

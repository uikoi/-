<template>
	<view class="item" @tap="check">
		<view class="top">
			<text>{{ type }}</text>
			<text>¥{{ vk.pubfn.priceFilter(info.money) }}</text>
		</view>
		<view class="end">
			<text class="time">
				{{ vk.pubfn.timeFormat(info._add_time, "yyyy-MM-dd hh:mm") }}
			</text>
			<text class="wait" v-if="info.status === 0">提现审核中</text>
			<text class="succ" v-if="info.status === 1">提现成功</text>
			<text class="erro" v-if="info.status === -1">提现失败</text>
		</view>
		<u-icon color="#999" name="arrow-right"></u-icon>
	</view>
</template>

<script>
var vk = uni.vk

export default {
	props: {
		info: {
			type: Object,
			default: () => {}
		}
	},
	computed: {
		type() {
			if (!this.info) return
			if (this.info.remark.type === 0) return "支付宝账号"
			if (this.info.remark.type === 1) return "银行卡账号"
			return "微信账号"
		}
	},
	methods: {
		check() {
			this.$emit("check", this.info)
		}
	}
}
</script>

<style lang="scss" scoped>
.item {
	padding: 30rpx 66rpx 30rpx 30rpx;
	background-color: #ffffff;
	position: relative;
}

.top,
.end {
	display: flex;
	justify-content: space-between;
}

.end {
	font-size: 24rpx;
	color: #999999;
	padding-top: 10rpx;
}

.u-icon {
	position: absolute;
	right: 24rpx;
	top: 50%;
	transform: translateY(-50%);
}

.wait {
	color: #f9ac28;
}

.succ {
	color: #4caf50;
}

.erro {
	color: #f44336;
}
</style>

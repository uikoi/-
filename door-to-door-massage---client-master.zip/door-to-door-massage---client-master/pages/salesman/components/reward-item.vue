<template>
	<view class="info">
		<view class="top">
			<text>{{ info.title }}</text>
			<text class="text1" v-if="info.value > 0">
				+{{ vk.pubfn.priceFilter(info.value) }}
			</text>
			<text class="text2" v-else>
				{{ vk.pubfn.priceFilter(info.value) }}
			</text>
		</view>
		<view class="end">
			<text>{{ vk.pubfn.timeFormat(info._add_time, "yyyy-MM-dd hh:mm") }}</text>
			<text>余额：{{ vk.pubfn.priceFilter(info.balance) }}</text>
		</view>
	</view>
</template>

<script>
export default {
	props: {
		info: {
			type: Object,
			default: () => {}
		}
	}
}
</script>

<style lang="scss" scoped>
.info {
	padding: 0 20rpx 28rpx;
	margin-bottom: 28rpx;
	border-bottom: 1rpx solid #f5f5f5;
}

.top,
.end {
	display: flex;
	justify-content: space-between;
}

.top {
	.text1 {
		color: #24c388;
	}
	.text2 {
		color: #fa3534;
	}
}

.end {
	color: #999;
	font-size: 24rpx;
	margin-top: 4rpx;
}
</style>

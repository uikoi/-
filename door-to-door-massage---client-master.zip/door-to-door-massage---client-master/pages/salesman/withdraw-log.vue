<template>
	<z-paging
		show-refresher-when-reload
		show-refresher-update-time
		class="app app-bg"
		v-model="list"
		ref="paging"
		@query="queryList"
	>
		<block v-for="item in list" :key="item._id">
			<log-item :info="item" @check="check"></log-item>
		</block>
	</z-paging>
</template>

<script>
var vk = uni.vk
import logItem from "./components/log-item"

export default {
	components: { logItem },
	data() {
		return {
			list: []
		}
	},
	methods: {
		// 查询订单列表
		queryList(pageIndex, pageSize) {
			vk.callFunction({
				url: "client/salesman.queryWithdrawalList",
				data: { pageSize, pageIndex }
			}).then(res => {
				this.$refs.paging.complete(res.rows)
			})
		},
		// 查看详情
		check(info) {
			vk.navigateTo(`/pages/salesman/withdraw-detail?id=${info._id}`)
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	padding-top: 20rpx;
}
</style>

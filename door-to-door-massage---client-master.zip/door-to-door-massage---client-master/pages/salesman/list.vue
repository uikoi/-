<template>
	<z-paging
		show-refresher-when-reload
		show-refresher-update-time
		class="app app-bg"
		v-model="list"
		ref="paging"
		@query="queryList"
	>
		<view class="item" v-for="item in list" :key="item._id">
			<u-image width="106" height="106" border-radius="50" :src="item.avatar"></u-image>
			<view class="right">
				<text>{{ item.nickname || "未知用户" }}</text>
				<text class="text">
					{{ vk.pubfn.timeFormat(item.invite_time, "yyyy-MM-dd hh:mm:ss") }}
				</text>
			</view>
		</view>
	</z-paging>
</template>

<script>
var vk = uni.vk // vk依赖

export default {
	data() {
		return {
			list: []
		}
	},
	methods: {
		// 查询商品列表
		queryList(pageIndex, pageSize) {
			vk.callFunction({
				url: "client/salesman.getUserList",
				data: { pageSize, pageIndex }
			}).then(res => {
				this.$refs.paging.complete(res.rows)
			})
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	box-shadow: 0 10rpx 10rpx rgba(0, 0, 0, 0.03) inset;
}

.item {
	display: flex;
	padding: 20rpx;
	background-color: #fff;
	margin: 20rpx;
	border-radius: 12rpx;
	.right {
		flex: 1;
		padding: 12rpx 0 12rpx 24rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		font-size: 30rpx;
		font-weight: bold;
		.text {
			font-size: 24rpx;
			line-height: 33rpx;
			color: #999999;
			font-weight: normal;
		}
	}
	.reward {
		color: #7657f0;
		margin: auto 0;
	}
}
</style>

<template>
	<view class="app app-bg">
		<z-paging show-refresher-when-reload ref="paging" v-model="list" @query="queryList">
			<view class="item" v-for="item in list" :key="item._id" @tap.stop="choose(item)">
				<view class="top">
					<view class="text">
						<text>{{ item.name + " " + item.mobile }}</text>
						<text class="def" v-if="item.is_default">默认</text>
					</view>
					<text>{{ item.formatted_address }}</text>
				</view>
				<view class="end">
					<view class="text right" @tap.stop="remove(item)">
						<u-icon name="trash" size="30"></u-icon>删除
					</view>
					<view class="text" @tap.stop="pageToForm(item)">
						<u-icon name="edit-pen" size="30"></u-icon>编辑
					</view>
				</view>
			</view>
		</z-paging>
		<view class="btn" @tap.stop="pageToForm()">+添加地址</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			type: "change",
			list: []
		}
	},
	onLoad(options = {}) {
		if (options.type === "select") {
			this.type = "select"
			uni.setNavigationBarTitle({ title: "选择地址" })
		} else {
			this.type = "change"
			uni.setNavigationBarTitle({ title: "我的收货地址" })
		}
	},
	onShow() {
		if (this.$refs.paging) this.$refs.paging.reload()
	},
	methods: {
		queryList(pageNo, pageSize) {
			vk.callFunction({
				url: "client/address.getList",
				data: { pageNo, pageSize }
			}).then(res => {
				this.$refs.paging.complete(res.rows)
			})
		},
		// 跳转到表单页面
		pageToForm(item) {
			let url = "./edit"
			if (item && item._id) url += `?_id=${item._id}`
			vk.navigateTo(url)
		},
		// 删除
		remove(item) {
			let text = `${item.name} ${item.mobile} ${item.formatted_address}`
			vk.confirm(text, "确定删除吗?", "确定", "取消", res => {
				if (!res.confirm) return
				vk.callFunction({
					url: "client/address.delete",
					title: "请求中...",
					data: { _id: item._id },
					success: () => {
						this.$refs.paging.reload()
					}
				})
			})
		},
		choose(item) {
			if (this.type == "select") {
				const eventChannel = this.getOpenerEventChannel()
				if (eventChannel.emit) eventChannel.emit("update", item)
				vk.navigateBack()
			}
		}
	}
}
</script>

<style lang="scss" scoped>
.item {
	margin: 30rpx 20rpx;
}

.top {
	background-color: #ffffff;
	border-radius: 16rpx;
	padding: 30rpx;
	display: flex;
	flex-direction: column;
	font-size: 24rpx;
	color: #999999;
	line-height: 36rpx;

	.text {
		font-weight: bold;
		font-size: 30rpx;
		color: #333333;
		padding-bottom: 14rpx;
	}

	.def {
		font-size: 24rpx;
		font-weight: normal;
		background-color: #24c388;
		color: #fff;
		padding: 0 10rpx;
		border-radius: 10rpx;
		margin-left: 10rpx;
	}
}

.end {
	display: flex;
	align-items: center;
	padding: 24rpx 0;
	background-color: #ffffff;
	border-radius: 16rpx;
	margin-top: 1rpx;

	.text {
		flex: 1;
		font-size: 24rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.right {
		border-right: 2rpx solid #f5f5f5;
	}

	.u-icon {
		margin-right: 6rpx;
	}
}

.btn {
	position: fixed;
	bottom: 60rpx;
	left: 30rpx;
	right: 30rpx;
	text-align: center;
	padding: 18rpx;
	background-color: #24c388;
	color: #ffffff;
	text-shadow: 0 6rpx 12rpx rgba(0, 143, 255, 0.16);
	border-radius: 60rpx;
	z-index: 999;
}
</style>

<template>
	<view class="app app-bg">
		<!-- 页面内容开始 -->
		<u-cell-group>
			<u-cell-item icon="weixin-fill" :icon-style="{color:'#09bb07'}" :title="$t('setting.wechat')" :value="isBindWeixin ? $t('setting.associated'):$t('setting.click-associate')" @click="bindWeixin"></u-cell-item>
		</u-cell-group>

		<view style="padding: 20rpx;">
			<text style="font-size: 12px;color: #959595;">{{ $t('setting.click-associate-tips') }}</text>
		</view>

		<!-- 页面内容结束 -->
	</view>
</template>

<script>
	var vk = uni.vk;			// vk依赖
	export default {
		data() {
			// 页面数据变量
			return {
				// init请求返回的数据
				data:{

				},
				// 表单请求数据
				form1:{

				},
				scrollTop:0
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		// 监听 - 页面每次【加载时】执行(如：前进)
		onLoad(options = {}) {
			vk = uni.vk;
			this.options = options;
			this.init(options);
		},
		// 监听 - 页面【首次渲染完成时】执行。注意如果渲染速度快，会在页面进入动画完成前触发
		onReady(){},
		// 监听 - 页面每次【显示时】执行(如：前进和返回) (页面每次出现在屏幕上都触发，包括从下级页面点返回露出当前页面)
		onShow() {},
		// 监听 - 页面每次【隐藏时】执行(如：返回)
		onHide() {},
		// 函数
		methods: {
			// 页面数据初始化函数
			init(options){
				let that = this;
				// #ifdef H5
				if (that.options.code) {
					if (!that.isBindWeixin){
						vk.userCenter.bindWeixin({
							data:{
								code: that.options.code
							},
							success:(data)=>{
								vk.alert("绑定成功");
							}
						});
					}
				}
				// #endif
			},
			pageTo(path){
				vk.navigateTo(path);
			},
			// 绑定微信
			bindWeixin(){
				let that = this;
				if (!that.isBindWeixin){
					// #ifdef H5
					let env = vk.h5.getEnv();
					if (env == "h5") {
						vk.toast("h5环境不支持绑定微信!");
						return false;
					} else if (env == "h5-weixin"){
						that.getWeixinCode();// 静默授权
						return false;
					}
					// #endif
					vk.userCenter.bindWeixin({
						success:(data)=>{
							vk.alert("绑定成功");
						}
					});
				}
			},
			// 微信公众号获取code
			// #ifdef H5
			getWeixinCode(){
				let redirect_uri = window.location.href.split("?")[0];
				vk.myfn.user.getH5WeixinCode({
					scope: "snsapi_userinfo",
					redirect_uri,
					state: "bind"
				});
			},
			// #endif
		},
		// 监听器
		watch:{

		},
		// 计算属性
		computed:{
			isBindWeixin(){
				let wx_openid = uni.vk.getVuex('$user.userInfo.wx_openid') || {};
				let openid;
				// #ifdef H5
				openid = wx_openid["h5-weixin"];
				// #endif
				// #ifdef MP-WEIXIN
				openid = wx_openid["mp-weixin"];
				// #endif
				// #ifdef APP-PLUS
				openid = wx_openid["app-plus"];
				// #endif
				return openid ? true : false;
			}
		}
	}
</script>
<style lang="scss" scoped>

</style>

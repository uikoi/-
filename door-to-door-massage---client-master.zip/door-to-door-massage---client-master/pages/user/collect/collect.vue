<template>
	<z-paging show-refresher-when-reload class="app app-bg" v-model="list" ref="paging" @query="queryList">
		<block v-for="(item, index) in list" :key="item._id">
			<shifu-item :info="item" @updateLike="updateL(index)"></shifu-item>
		</block>
	</z-paging>
</template>

<script>
var vk = uni.vk
import shifuItem from "@/pages/index/components/shifu-item"

export default {
	components: { shifuItem },
	data() {
		return {
			list: []
		}
	},
	methods: {
		// 查询列表
		queryList(pageIndex, pageSize) {
			let adr = vk.getStorageSync("adr")
			vk.callFunction({
				url: "client/user.queryMyCollect",
				data: { pageSize, pageIndex, lonlat: adr }
			}).then(res => {
				this.$refs.paging.complete(res.rows)
			})
		},
		// 更新收藏
		updateL(index) {
			this.list.splice(index, 1)
			uni.$emit("refreshShifuList")
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	padding-top: 20rpx;
}
</style>

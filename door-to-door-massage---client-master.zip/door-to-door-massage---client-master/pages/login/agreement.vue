<template>
	<view class="app app-bg">
		<u-parse :html="str"></u-parse>
	</view>
</template>

<script>
var vk = uni.vk
export default {
	data() {
		return {
			// init请求返回的数据
			str: ""
		}
	},
	onLoad(options = {}) {
		vk = uni.vk
		this.options = options
		this.init(options)
	},
	methods: {
		// 页面数据初始化函数
		init(options) {
			vk.callFunction({
				url: "client/pub.getPolicy",
				title: "加载中...",
				data: { type: options.type }
			}).then(res => {
				uni.setNavigationBarTitle({ title: res.data.title })
				this.str = res.data.content
			})
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	padding: 20rpx 30rpx;
	line-height: 40rpx;
	font-size: 28rpx;
}
</style>

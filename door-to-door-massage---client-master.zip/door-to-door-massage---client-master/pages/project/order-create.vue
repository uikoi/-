<template>
	<view class="app app-bg">
		<view class="label">服务地址</view>
		<view class="address" v-if="address._id" @tap="select">
			<image class="icon2" src="@/static/icon/icon_order_location.png"></image>
			<view class="content">
				<text class="name">{{ address.name + " " + address.mobile }}</text>
				<text>{{ address.formatted_address }}</text>
			</view>
			<image class="icon3" src="@/static/icon/right.png"></image>
		</view>
		<view class="address empty" v-else @tap="select">
			<image class="icon" src="@/static/icon/icon_add.png"></image>
			<text>添加服务地址</text>
		</view>
		<view class="item">
			<view class="info">
				<u-image
					border-radius="12"
					height="150"
					width="150"
					:src="project.thumb"
				></u-image>
				<view class="right">
					<text class="name">{{ project.title }}</text>
					<view class="time">
						<u-icon name="clock-fill" color="#24C388" size="30"></u-icon>
						<text>{{ project.time }}分钟</text>
					</view>
					<view class="money">
						<text style="font-weight: bold; flex: 1">
							{{ vk.pubfn.priceFilter(project.price) }}
						</text>
						<u-number-box
							bg-color="#F4F6F9"
							input-width="56"
							v-model="buyNum"
							:min="1"
							:disabled-input="true"
						></u-number-box>
					</view>
				</view>
			</view>
		</view>
		<view class="item shifu" v-if="shifu && shifu._id">
			<view class="shifu_top">
				<text class="label">服务{{ project.cate === 1 ? "技师" : "达人" }}</text>
				<text @tap="openShifu">更换{{ project.cate === 1 ? "技师" : "达人" }}</text>
				<image class="icon" src="@/static/icon/right.png" @tap="openShifu"></image>
			</view>
			<view class="shifu_end">
				<image class="avatar" mode="aspectFill" :src="shifu.avatar"></image>
				<image class="tip" :src="shifu.hot" v-if="shifu.hot"></image>
				<view class="right">
					<view class="nickname">{{ shifu.nickname }}</view>
					<view class="tips">
						已服务{{ shifu.order || 0 }}单 | 评价{{ shifu.talk || 0 }}
					</view>
					<view class="text">{{ shifu.content || "欢迎下单" }}</view>
				</view>
				<view class="time">最近可约: {{ shifu.near }}</view>
				<view class="btn" @tap="checkInfo">查看详情</view>
			</view>
		</view>
		<view class="item" @tap="openTime">
			<text class="label">服务时间</text>
			<text class="value" v-if="time">{{ showTime }}</text>
			<text class="value place" v-else>请选择</text>
			<image class="icon" src="@/static/icon/right.png"></image>
		</view>
		<view class="item_bg">
			<view class="ticket tt2">
				<text class="label">路费</text>
				<u-icon name="question-circle" color="#24c388" size="30" @tap="openTips"></u-icon>
				<text class="value disc">¥{{ vk.pubfn.priceFilter(freight) }}</text>
			</view>
			<view class="ticket" @tap="popShow = true">
				<text class="label">优惠券</text>
				<text class="value disc" v-if="ticket">
					-¥{{ vk.pubfn.priceFilter(ticket.coupon_rule.discount_amount) }}
				</text>
				<text class="value place" v-else>请选择</text>
				<image src="@/static/icon/right.png" class="icon"></image>
			</view>
		</view>
		<view class="label top">备注</view>
		<view class="remark">
			<u-input v-model="remark" type="textarea" height="180" />
		</view>
		<view class="order_tips" v-if="orderTips">
			<u-icon name="info-circle-fill" color="#24c388" size="30"></u-icon>
			<view class="tit">下单须知</view>
			<text class="text">{{ orderTips }}</text>
		</view>
		<view class="btns" @tap="send">
			<view class="price">¥{{ totalMoney }}</view>
			<view class="btn">立即支付</view>
		</view>
		<!-- 优惠券 -->
		<u-popup v-model="popShow" mode="bottom" closeable border-radius="30" length="45%">
			<ticket-mine
				:list="coupons"
				:price="proMoney"
				@itemClick="selectCoupon"
			></ticket-mine>
		</u-popup>
		<!-- 服务时间 -->
		<u-popup v-model="popShow2" mode="bottom" closeable border-radius="30" length="65%">
			<service-time
				v-if="popShow2"
				ref="serTime"
				:ins="inServe"
				:agent="timeAgent"
				:shifu="timeShifu"
				@select="selectTime"
			></service-time>
		</u-popup>
	</view>
</template>

<script>
var vk = uni.vk // vk依赖
import ticketMine from "./components/ticket-mine"
import serviceTime from "./components/service-time"

export default {
	components: { ticketMine, serviceTime },
	data() {
		return {
			// 基础信息
			sid: "",
			pid: "",
			// 订单信息
			address: {
				_id: "",
				name: "",
				mobile: "",
				detail: "",
				formatted_address: ""
			},
			shifu: { _id: "", avatar: "", nickname: "", location: { coordinates: [] } },
			time: "",
			project: { _id: "", title: "", thumb: "", time: 0, price: 0 },
			buyNum: 1,
			ticket: null,
			remark: "",
			freight: 0,
			// 弹框
			coupons: [],
			timeAgent: null,
			timeShifu: null,
			inServe: null,
			wayTips: "",
			orderTips: "",

			popShow: false,
			popShow2: false
		}
	},
	onLoad(opt = {}) {
		if (!opt.sid || !opt.pid) {
			return vk.toast("参数不足", "none", 1000, () => {
				vk.navigateBack()
			})
		} else {
			this.sid = opt.sid
			this.pid = opt.pid
		}
		this.init()
	},
	computed: {
		proMoney() {
			return this.project.price * this.buyNum
		},
		showTime() {
			let now = vk.pubfn.timeFormat(new Date(), "MM-dd")
			let time = new Date(this.time).getTime()
			if (this.time.indexOf(now) != -1) {
				return vk.pubfn.timeFormat(time, "今天 hh:mm")
			}
			return vk.pubfn.timeFormat(time, "MM-dd hh:mm")
		},
		totalMoney() {
			let money = this.proMoney + this.freight
			if (this.ticket) money -= this.ticket.coupon_rule.discount_amount
			return vk.pubfn.priceFilter(money)
		}
	},
	methods: {
		// 初始化
		init() {
			vk.callFunction({
				url: "client/order.queryOrderInfo",
				title: "获取中...",
				data: { pid: this.pid, sid: this.sid },
				success: res => {
					this.project = res.project
					if (res.shifu) {
						let now = vk.pubfn.timeFormat(new Date(), "hh:mm")
						const { shifu_time, agent_time, service_time } = res
						for (let i = 0; i < agent_time.length; i++) {
							let t = agent_time[i]
							let a = shifu_time.indexOf(t) === -1
							let b = service_time.indexOf(t) === -1
							if (t > now && a && b) {
								res.shifu.near = t
								break
							}
						}
						if (!res.shifu.near) res.shifu.near = "暂无"
					}
					this.shifu = res.shifu
					this.coupons = res.coupons
					if (res.coupon) this.ticket = res.coupon
					this.timeAgent = res.time_agent
					this.timeShifu = res.time_shifu
					this.inServe = res.in_serve
					this.wayTips = res.way_tips
					this.orderTips = res.order_tips
					if (res.address) {
						this.address = res.address
						this.changeFreight()
					}
				}
			})
		},
		// 选择地址
		select() {
			vk.navigateTo({
				url: `/pages/user/address/list?type=select`,
				events: {
					update: v => {
						this.address = {
							_id: v._id,
							name: v.name,
							mobile: v.mobile,
							detail: v.position.name,
							formatted_address: v.formatted_address,
							location: v.location
						}
						this.changeFreight()
					}
				}
			})
		},
		// 选择优惠券
		selectCoupon(e) {
			this.ticket = e
			this.popShow = false
		},
		// 选择服务时间
		openTime() {
			this.popShow2 = true
			this.$nextTick(() => {
				this.$refs.serTime.selected = this.time
			})
		},
		selectTime(e) {
			this.time = e
			this.popShow2 = false
		},
		// 选择技师
		openShifu() {
			let t = this.project.cate === 1 ? "更换技师" : "更换达人"
			vk.navigateTo({
				url: `/pages/project/shifu?id=${this.pid}&from=create&btnText=${t}`,
				events: {
					update: data => {
						this.changeShifuTime(data)
					}
				}
			})
		},
		changeShifuTime(data) {
			this.sid = data._id
			if (!data.open_time_arr) {
				data.open_time_arr = []
			}
			let nowDay = vk.pubfn.timeFormat(new Date(), "yyyy-MM-dd")
			let obj = vk.pubfn.getListItem(data.open_time_arr, "day", nowDay)
			if (!obj) {
				data.open_time_arr.push({ day: nowDay, times: [] })
			}
			this.shifu = data
			this.timeAgent = data.agentInfo.open_time_arr
			this.timeShifu = data.open_time_arr
			this.inServe = data.in_serve
			this.time = ""
			this.popShow2 = false
		},
		checkInfo() {
			vk.navigateTo(`/pages/shifu/detail?id=${this.shifu._id}&from=create`)
		},
		// 计算路费
		async changeFreight() {
			const { shifu, address } = this
			if (!shifu || !address.location) return
			const res = await vk.callFunction({
				url: "client/order.cpuHomeCarMoney",
				title: "计算中...",
				data: { pid: this.pid, addr: address, o: shifu.location.coordinates }
			})
			if (res.code !== 0) return
			this.freight = res.m
		},
		// 路费说明
		openTips() {
			vk.alert(this.wayTips, "路费说明")
		},
		// 提交
		send() {
			const { address, time, buyNum, ticket, remark } = this
			if (!address._id) return vk.toast("请选择地址")
			if (!time) return vk.toast("请选择服务时间")

			vk.callFunction({
				url: "client/order.createdOrder",
				title: "提交中...",
				needAlert: true,
				data: { time, buyNum, ticket, remark, address, sid: this.sid, pid: this.pid },
				success: res => {
					vk.redirectTo(`./order-pay?id=${res.oid}`)
				}
			})
		}
	}
}
</script>

<style lang="scss" scoped>
.app {
	padding: 20rpx 20rpx 118rpx;
}

.label {
	font-weight: bold;
	padding: 0 10rpx 0 4rpx;
}

.address {
	background-color: #ffffff;
	border-radius: 12rpx;
	color: #999999;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 18rpx;
	padding: 20rpx 24rpx 28rpx;
	min-height: 142rpx;
	.icon {
		width: 52rpx;
		height: 52rpx;
		margin-right: 20rpx;
	}
	.icon2 {
		width: 44rpx;
		height: 52rpx;
		margin-right: 20rpx;
	}
	.content {
		font-size: 26rpx;
		color: #999999;
		display: flex;
		flex-direction: column;
		flex: 1;
		padding: 0 6rpx;
		.name {
			font-size: 28rpx;
			font-weight: bold;
			color: #212121;
			line-height: 50rpx;
		}
	}
	.icon3 {
		width: 30rpx;
		height: 30rpx;
		margin: 12rpx -8rpx 0 0;
	}
}

.empty {
	min-height: 184rpx;
	padding-top: 28rpx;
}

.item {
	background-color: #ffffff;
	border-radius: 12rpx;
	padding: 16rpx 20rpx;
	margin: 20rpx 0;
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	.value {
		flex: 1;
		text-align: right;
		padding: 18rpx 0;
		font-size: 26rpx;
	}
	.place {
		color: #999999;
	}
	.icon {
		width: 30rpx;
		height: 30rpx;
		margin: 0 -6rpx 0 6rpx;
	}
}
.item_bg {
	border-radius: 12rpx;
	background-color: #ffffff;
	margin-bottom: 20rpx;
	padding: 6rpx 20rpx;
	.ticket {
		display: flex;
		align-items: center;
		padding: 26rpx 0;
		.value {
			flex: 1;
			text-align: right;
		}
		.disc {
			color: #ff0000;
		}
		.place {
			color: #999;
		}
		.icon {
			width: 30rpx;
			height: 30rpx;
			margin: 0 -6rpx 0 6rpx;
		}
	}
	.tt2 {
		border-bottom: 1rpx solid #eee;
	}
}
.shifu {
	padding: 20rpx;
	display: block;
	.shifu_top {
		display: flex;
		align-items: center;
		color: #999;
		font-size: 26rpx;
		.label {
			flex: 1;
			color: #333;
			font-size: 28rpx;
		}
	}
	.shifu_end {
		margin-top: 20rpx;
		padding: 20rpx;
		border-radius: 12rpx;
		background-color: #f4f6f9;
		display: flex;
		align-items: center;
		position: relative;
		.avatar {
			width: 146rpx;
			height: 146rpx;
		}
		.tip {
			width: 146rpx;
			height: 146rpx;
			position: absolute;
		}
		.right {
			height: 136rpx;
			width: calc(100% - 156rpx);
			padding-left: 20rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
		}
		.nickname {
			font-weight: bold;
			font-size: 30rpx;
		}
		.tips {
			color: #999;
			font-size: 24rpx;
		}
		.text {
			color: #999;
			font-size: 24rpx;
			text-overflow: ellipsis;
			overflow: hidden;
			word-break: break-all;
			white-space: nowrap;
		}
		.time {
			position: absolute;
			right: 0;
			top: 0;
			color: #24c388;
			font-size: 24rpx;
			padding: 6rpx 14rpx;
			border-radius: 0 12rpx 0 12rpx;
			background-color: rgba(36, 195, 136, 0.12);
		}
		.btn {
			position: absolute;
			right: 16rpx;
			color: #24c388;
			font-size: 24rpx;
			padding: 4rpx 18rpx;
			border: 1rpx solid #24c388;
			border-radius: 28rpx;
		}
	}
}

.info {
	padding: 16rpx 20rpx;
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	background-color: #f4f6f9;
	border-radius: 12rpx;
	margin: 10rpx 0;
	width: 100%;
	.right {
		flex: 1;
		padding-left: 20rpx;
		.name {
			font-weight: bold;
			font-size: 28rpx;
		}
		.time {
			font-size: 24rpx;
			color: #999999;
			padding: 12rpx 0 18rpx;
			display: flex;
			align-items: flex-end;
		}
		.u-icon {
			margin-right: 6rpx;
		}
		.money {
			color: #ff0000;
			font-size: 30rpx;
			display: flex;
			align-items: center;
			padding-left: 4rpx;
			&::before {
				content: "¥";
				font-size: 24rpx;
				font-weight: normal;
				margin-right: 2rpx;
			}
		}
		/deep/ .u-icon-plus,
		/deep/ .u-icon-minus {
			background-color: #24c388 !important;
			color: #fff !important;
			width: 44rpx !important;
			border-radius: 4rpx !important;
			height: 44rpx !important;
		}
		/deep/ .u-icon-disabled {
			background-color: #d1d1d1 !important;
			color: #999999 !important;
		}
		/deep/ .num-btn {
			top: -2rpx !important;
			font-weight: normal;
		}
	}
}

.top {
	padding: 26rpx 20rpx 0;
	background-color: #fff;
	border-radius: 12rpx 12rpx 0 0;
}

.remark {
	padding: 6rpx 20rpx;
	background-color: #f5f5f5;
	border-radius: 0 0 12rpx 12rpx;
	border-color: #fff;
	border-style: solid;
	border-width: 20rpx 20rpx 30rpx;
}

.btns {
	position: fixed;
	z-index: 99;
	bottom: 0;
	left: 0;
	right: 0;
	height: 108rpx;
	background-color: #fff;
	box-shadow: 0px -6px 20px rgba(0, 0, 0, 0.06);
	padding: 16rpx 30rpx;
	display: flex;
	align-items: center;
	justify-content: space-between;
	.price {
		font-size: 36rpx;
		font-weight: bold;
		color: #ff0000;
		display: flex;
		align-items: center;
		&::before {
			content: "合计";
			font-size: 24rpx;
			font-weight: normal;
			margin-right: 12rpx;
			color: #666;
		}
	}
	.btn {
		color: #fff;
		width: 368rpx;
		height: 100%;
		border-radius: 38rpx;
		background-color: #24c388;
		display: flex;
		align-items: center;
		justify-content: center;
	}
}

.order_tips {
	margin-top: 28rpx;
	line-height: 40rpx;
	.tit {
		font-weight: bold;
		display: inline-block;
		margin-left: 10rpx;
	}
	.text {
		display: block;
		padding: 10rpx 6rpx;
		font-size: 24rpx;
		color: #999;
	}
}
</style>

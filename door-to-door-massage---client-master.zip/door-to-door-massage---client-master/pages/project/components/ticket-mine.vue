<template>
	<view class="list">
		<view class="title">使用优惠券</view>
		<scroll-view scroll-y class="main">
			<view class="item" v-for="item in list" :key="item._id">
				<view class="left">
					<view class="name">{{ item.coupon_name }}</view>
					<view class="time">有效期至：{{ showTime(item) }}</view>
				</view>
				<view class="btn_bg">
					<view class="btn" v-if="flag(item)" @tap="use(item)">立即使用</view>
					<view class="btn" style="filter: grayscale(100%)" v-else>无法使用</view>
				</view>
			</view>
			<u-empty text="没有优惠券" mode="coupon" v-if="list.length <= 0"></u-empty>
		</scroll-view>
	</view>
</template>

<script>
export default {
	props: {
		list: {
			type: Array,
			default: () => []
		},
		mid: {
			type: String,
			default: ""
		},
		price: {
			type: Number,
			default: 0
		}
	},
	methods: {
		showTime(item) {
			let time = item.exp_time
			if (time === 0) {
				return "永久有效"
			}
			return vk.pubfn.timeFormat(time, "yyyy-MM-dd")
		},
		flag(item) {
			let now = new Date().getTime()
			let f1 = item.coupon_rule.min_amount <= this.price
			let f2 = item.exp_time > now || item.exp_time === 0
			return f1 && f2
		},
		use(item) {
			this.$emit("itemClick", item)
		}
	}
}
</script>

<style lang="scss" scoped>
.list {
	padding: 26rpx;
	background-color: #f5f5f5;
	height: 100%;
}

.title {
	font-size: 30rpx;
	font-weight: bold;
	line-height: 45rpx;
	text-align: center;
	padding-bottom: 8rpx;
}

.main {
	height: calc(100% - 54rpx);
}

.item {
	background: url("https://mp-d0bdc000-db91-44a8-852b-e6f607a7ca19.cdn.bspapp.com/cloudstorage/c0139d19-0e11-4e64-a8da-9a9201bf7247.png") no-repeat center;
	background-size: 100% 100%;
	padding: 14rpx 0 14rpx 30rpx;
	height: 160rpx;
	box-sizing: border-box;
	display: flex;
	align-items: center;
	margin-top: 26rpx;

	.left {
		flex: 1;
		font-size: 28rpx;

		.time {
			font-size: 24rpx;
			line-height: 40rpx;
			color: #999999;
			padding-top: 6rpx;
		}
	}

	.btn_bg {
		width: 216rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		height: 100%;

		&::before {
			content: "";
			width: 0;
			height: 100%;
			border-left: 1rpx dotted #c29f80;
			position: absolute;
			left: 0;
			top: 0;
		}

		.btn {
			font-size: 28rpx;
			background-color: #67c2ff;
			color: #ffffff;
			padding: 6rpx 20rpx;
			border-radius: 26rpx;
		}
	}
}
</style>
